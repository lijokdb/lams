<section class="footer">
    <div class="container">
      <div class="col-lg-12 col-md-12 col-sm-12 padding-lr">
        <div class="row">
		
		<?php 
		$testimonials = $this->db->get($this->db->dbprefix('testimonials_settings'))->result();
		// echo "<pre>"; print_r($testimonials); die();
		if(count($testimonials)>0) {?>
          <div class="col-lg-3 col-md-3 col-sm-4">
            <div class="footer_div">
              <div class="footer_heading">
                <h5><?php echo $this->lang->line('testimonials');?> </h5>
              </div>
              <!--./footer_heading-->
              
              <div class="footer_social_links">
                <div  id="testimonials-row">
                  <div class="row">
                    <div class="col-md-12 column">
                      <div class="carousel slide" id="testimonials-rotate">
                        <ol class="carousel-indicators">
                          <li class="active" data-slide-to="0" data-target="#testimonials-rotate"> </li>
                          <li data-slide-to="1" data-target="#testimonials-rotate"> </li>
                          <li data-slide-to="2" data-target="#testimonials-rotate"> </li>
                        </ol>
                        <div class="carousel-inner">
                          <?php $i=0; 
						  $this->db->select('user_name,content');
						  $testimonials = $this->db->get_where('vbs_testimonials_settings',array('status'=>'Active'))->result();
						  foreach($testimonials as $row):?>
						  <div class="item <?php if($i++==0) echo ' active';?>">
                            <div class="testimonials col-md-10 padding-p-0">
                              <h3> <?php echo $row->content; ?><br>
                                <small class="name"> <?php echo $row->user_name; ?></small> </h3>
                            </div>
                            <div class="clearfix"></div>
                          </div>
                          <?php endforeach; ?>
                        </div>
                      </div>
                      <div class="pull-right"> <a class="left" href="#testimonials-rotate" data-slide="prev"><span class="glyphicon glyphicon-chevron-left"></span></a> <a class="right" href="#testimonials-rotate" data-slide="next"><span class="glyphicon glyphicon-chevron-right"></span></a>
                        <div class="clearfix"></div>
                      </div>
                    </div>
                  </div>
                </div>
                <!--end of container-->
                <div class="clearfix"></div>
              </div>
            </div>
            <!--./footer_div--> 
          </div>
		<?php } ?>
          <!--./col-lg-3-->
          
		  
		  
		  <div class="col-lg-2 col-md-2 col-sm-4">
            <div class="footer_div">
              <div class="footer_heading">
                <h5><?php echo $this->lang->line('our_company');?></h5>
              </div>
              <!--./footer_heading-->
              <div class="recent_tweet">
                <ul>
                  <!-- <li> <a href="#">Our Fleet </a></li> -->
                  <li> <a href="<?php echo site_url();?>/welcome/contactUs"><?php echo $this->lang->line('contact_us');?></a></li>
                  <li><a href="<?php echo site_url();?>/welcome/faqs"><?php echo $this->lang->line('FAQs');?></a></li>
                 <li><a href="<?php echo site_url();?>/welcome/testimonials"> <?php echo $this->lang->line('testimonials');?></a></li>
                </ul>
              </div>
            </div>
            <!--./footer_div--> 
          </div>
		  
		  
          <!--./col-lg-3-->
          <div class="col-lg-2 col-md-2 col-sm-4">
            <div class="footer_div">
			
              <div class="footer_heading"> 
			  <h5><?php echo $this->lang->line('pages');?></h5>
			  </div>
              <!--./footer_heading-->
              <div class="recent_tweet">
                <ul>
                
                <?php 
				  
				  $this->db->select('id,name,parent_id');
				  $sub_categories = $this->db->get_where('vbs_aboutus',array('is_bottom' => '1','status' => 'Active'))->result();
				  if(count($sub_categories) > 0)
				  foreach($sub_categories as $sub_row) {
				  
				  ?>
				  <li><a href="<?php echo site_url(); ?>/page/index/<?php echo $sub_row->id; ?>/<?php echo $sub_row->name;?>"><?php echo $sub_row->name;?></a></li>
				  
				  <?php } ?>
               
                </ul>
              </div>
            </div>
            <!--./footer_div--> 
          </div>
          
		  
		  
          <div class="col-md-2">
		  
            <p class="credit-cards"><label><?php echo $this->lang->line('cards_we_accept');?></label><img alt="Cards we accept" src="<?php echo base_url();?>/assets/system_design/images/cards1.gif"></p>
          </div>
		  
		  
        </div>
      </div>
    </div>
    <!--./container--> 
  </section>
  <section class="bottom_footer">
    <div class="container">
      <div class="col-md-8 padding-lr">
        <div class="copyright-left">
         <?php if(isset($site_settings->rights_reserved_content)) { ?>
          <p><?php echo $site_settings->rights_reserved_content;?></p>
        <?php } ?>
        </div>
      </div>
      <div class="col-md-4 padding-lr">
        <div class="copyright-left right-foo">
         
		  <?php if(isset($site_settings->design_by)) { ?>
          <p><?php echo $this->lang->line('design_by');?><a href="<?php if(isset($site_settings->url_for_design_by)) echo $site_settings->url_for_design_by;?>" target="_blank"> <?php echo  $site_settings->design_by;?></a></p>
        <?php } ?>
        </div>
      </div>
    </div>
  </section>    
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 

<!-- Include all compiled plugins (below), or include individual files as needed --> 

 <script src="<?php echo base_url();?>assets/system_design/scripts/chosen.jquery.min.js"></script>

         <script>
$(function() {
$(".chzn-select").chosen();});
        </script>
 
<script src="<?php echo base_url();?>assets/system_design/scripts/bootstrap.min.js"></script> 
<script src="<?php echo base_url();?>assets/system_design/scripts/BeatPicker.min.js"></script>

    <script src="<?php echo base_url();?>assets/system_design/scripts/timepicki.js"></script>
    <script>
    	$('#timepicker1').timepicki({increase_direction:'up'});
		$('#timepicker2').timepicki({increase_direction:'up'});
 	 
    </script>
<?php if(in_array("homebooking",$css_type)) { ?>

<?php echo $this->load->view('site/common/script'); ?>

<?php } ?>

<?php if(in_array("onlinebooking",$css_type)) { ?>

<?php echo $this->load->view('site/common/online_script'); ?>

<?php } ?>
<!--Date Table--> 
<?php if(in_array("datatable",$css_type)) { ?>
<script type="text/javascript" language="javascript" src="<?php echo base_url();?>assets/system_design/scripts/jquery.dataTables.js"></script> 
 <script type="text/javascript" language="javascript" class="init">

$(document).ready(function() {
	$('#example').dataTable();
	$('.example').dataTable();  
} );

	</script> 
	<?php } ?>
	<!--Date Table--> 
	


 <script type="text/javascript" language="javascript" class="init">

 
 
 function setActiveOnlinePackage(id) {
	numid = id.split('_')[1];
	$('#cars_data_list div').removeClass('active');
	$('li').removeClass('active');
	$('#'+id).parent().closest('ul').addClass('active');
	$('#'+id).parent().parent().addClass('car-sel-bx active');
	
}

	</script>
	<!--Slider--> 
<?php if(in_array("slider",$css_type)) { ?> 
	<?php } ?>
	<!--Slider--> 
	
    
</body>
</html>