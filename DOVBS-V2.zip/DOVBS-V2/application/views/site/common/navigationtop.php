<div class="container-fluid main-menutop">
   <div class="container padding-p-0">
      <div class="row">
         <div class="col-md-2 padding-p-l">
            <a href="<?php echo site_url();?>/auth/index/home">
                <?php if(isset($site_settings->site_logo) && $site_settings->site_logo != " ") {?>
               <div class="logo">
                  <img src="<?php echo base_url();?>uploads/site_logo/<?php if(isset($site_settings->site_logo)) echo $site_settings->site_logo;?>" width="190" height="145" > 
               </div>
			 <?php } else
				 echo "";?>
			   
			   
            </a>
         </div>
         <div class="col-md-10 padding-p-r">
            <nav role="navigationtop" class="navbar navbar-default menu-total">
               <div class="navbar-header">
                  <button aria-controls="navbar" aria-expanded="false" data-target="#navbartop" data-toggle="collapse" class="navbar-toggle collapsed nav-bar-btn" type="button"> <span class="sr-only"><?php echo $this->lang->line('toggle_navigation');?></span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
               </div>
               <div class="collapse navbar-collapse res-menu" id="navbartop">
                  <ul class="nav navbar-nav menu" style="padding-top:10%; padding-bottom:10%">
                     <li><a href="http://www.kochiraja.in">HOME </a></li>
                     <li><a href="services.html">APPLIANCE</a></li>
                     <li><a href="services.html">TOURS</a></li>
                     <li><a href="./allin1/toursindex.html">TRAVELS</a></li>
                     
                    
                     <?php                         
                        $this->db->select('id,name');
                        $categories = $this->db->get_where('vbs_aboutus',array('parent_id' => 0,'status'=>'Active'))->result();
                        
                        if(count($categories) > 0)
                        foreach($categories as $row):
                        ?>
                     <li class="drop-menu menu-drop<?php if(isset($active_class) && $active_class==$row->name) echo " active";?>">
                        <a href="#" aria-expanded="false" role="button" data-toggle="dropdown" class="dropdown-toggle"><?php echo $row->name;?><span class="caret"></span> </a>
                        <ul role="menu" class="dropdown-menu drop-menu">
                           
                        </ul>
                     </li>
                     <?php endforeach;?>
                     <!-- kalyan end -->
                     
                     <li><a href="blog.html">BLOG</a></li>
                     <li><a href="contact.html">CONTACT</a></li>
                    
                  </ul>
               </div>
               <!--/.nav-collapse --> 
            </nav>
         </div>
      </div>
   </div>
</div>
<?php if(isset($bread_crumb) && $bread_crumb==true) {?>
<?php } ?>