<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="keywords" content="<?php if(isset($meta_keywords)) echo $meta_keywords; elseif(isset($this->config->item('seo_settings')->site_keywords)) echo $this->config->item('seo_settings')->site_keywords; ?>"/>

      <meta name="description" content="<?php if(isset($meta_description)) echo $meta_description; elseif(isset($this->config->item('seo_settings')->meta_description)) echo $this->config->item('seo_settings')->meta_description; ?>" />

      <title><?php if(isset($title)) echo $title; if(isset($site_settings->site_title) && $site_settings->site_title != "") 
		  echo " - ".$site_settings->site_title;
		else echo "Cab Booking System";?></title>


		<?php if(isset($this->config->item('seo_settings')->google_analytics)) echo "<script>".$this->config->item('seo_settings')->google_analytics."</script>"; ?>

      <!-- Bootstrap -->
      <link href="<?php echo base_url();?>assets/system_design/css/styles.css" rel="stylesheet">
      <?php if(isset($site_settings->site_theme) && $site_settings->site_theme == "Red") {  ?>
      <link href="<?php echo base_url();?>assets/system_design/css/cab-2ntheame.css" rel="stylesheet">
      <?php } else { ?>
      <link href="<?php echo base_url();?>assets/system_design/css/cab.css" rel="stylesheet">
      <?php } ?>
      <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
      <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
      <![endif]-->
   </head>
   <body>
      <header class="bg">
      <div class="container-fluid top-hedd">
         <div class="container padding-p-0">
            <div class="row">
               <div class="col-md-12 padding-p-0">
                  <div class="top-section">
                     <div class="col-md-7">
                        <div class="col-md-4 padding-p-r">
                           <div class="tot-top">
                              <div class="phone" style="padding-top:7px"> <i class="fa fa-phone"></i> </div>
                              <aside><?php echo $site_settings->land_line;?></aside>
                           </div>
                        </div>
                        <?php if(!$this->ion_auth->logged_in()) { ?>
                        <div class="col-md-4 padding-p-r">
                           <div class="tot-top">
                              <div class="phone"style="padding-top:7px"> <i class="fa fa-user"></i> </div>
                              <aside class="col">  <a href="<?php echo site_url();?>/auth/create_user" ><?php echo $this->lang->line('create_account'); ?> </a> </aside>
                           </div>
                        </div>
                        <div class="col-md-4 padding-p-r">
                           <div class="tot-top">
                              <div class="phone"style="padding-top:7px"> <i class="fa fa-lock"></i> </div>
                              <aside class="col"> <a href="<?php echo site_url();?>/auth/login" ><?php echo $this->lang->line('login'); ?> </a> </aside>
                           </div>
                        </div>
                        <?php } else { ?>
                        <a href="<?php echo site_url();?>/auth" >
                           <div class="col-md-4 padding-p-r">
                              <div class="tot-top">
                                 <div class="phone"style="padding-top:7px"> <i class="fa fa-user"></i> </div>
                                 <aside> <?php echo $this->session->userdata('username'); ?> </aside>
                              </div>
                           </div>
                        </a>
                        <?php } ?>
                     </div>
                     <div class="col-md-5 padding-p-r">
                        <div class="social-icons">
                           <ul>
                              <?php 
                                 $social_networks = $this->base_model->run_query("SELECT * FROM vbs_social_networks");
                                 
                                 		
                                 //social_networks
                                 
                                 	 if($social_networks[0]->facebook){?>
                              <li> <a href="<?php echo $social_networks[0]->facebook; ?>"   target="_blank">
                                 <i class="fa fa-facebook"></i> </a> 
                              </li>
                              <?php }
                                 if($social_networks[0]->twitter){?>
                              <li> <a href="<?php echo $social_networks[0]->twitter; ?>"   target="_blank">
                                 <i class="fa fa-twitter"></i> </a> 
                              </li>
                              <?php }
                                 if($social_networks[0]->linkedin){?>
                              <li> <a href="<?php  echo $social_networks[0]->linkedin; ?>"  target="_blank"> 
                                 <i class="fa fa-linkedin"></i> </a> 
                              </li>
                              <?php }
                                 if($social_networks[0]->google_plus){?>
                              <li> <a href="<?php echo $social_networks[0]->google_plus; ?>" target="_blank"> 
                                 <i class="fa fa-google-plus"></i> </a> 
                              </li>
                              <?php }?>

                           </ul>
                        </div>
						<?php if(isset($site_settings->language_dropdown) && $site_settings->language_dropdown == "Enable") { ?>
                        <div class="selec" id="uli">
                           <a href="#"><?php echo $this->lang->line('lang');?></a>
                           <div id="ld">
                              <ul>
                                 <li> <?php echo anchor($this->lang->switch_uri('en'),'English');?> </li>
                                 <li><?php echo anchor($this->lang->switch_uri('fr'),'French');?> </li>
                                 <li><?php echo anchor($this->lang->switch_uri('pt'),'Português');?> </li>
                                 <li><?php echo anchor($this->lang->switch_uri('de'),'German');?> </li>
                                 <li><?php echo anchor($this->lang->switch_uri('ru'),'Russian');?> </li>
                                 <li><?php echo anchor($this->lang->switch_uri('tr'),'Turkish');?> </li>
                              </ul>
                           </div>
                        </div>
						<?php } ?>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   <script src="<?php echo base_url();?>assets/system_design/scripts/jquery.min.js"></script>
      <script src="<?php echo base_url();?>/assets/system_design/form_validation/js/jquery.validate.min.js" type="text/javascript"></script>
      <script src="<?php echo base_url();?>/assets/system_design/form_validation/js/additional-methods.min.js" type="text/javascript"></script>