</header>
<div class="container-fluid">
  <div class="container padding-p-0">
    <div class="row">
      <div class="col-md-6">
	   <?php echo $this->session->flashdata('message'); ?>
        <div class="left-side-cont">
		
          <article class="content">
  <?php 
			  $attributes = array("name" => 'contact_form', 'id' => "contact_form");
			  echo form_open("welcome/contactUs",$attributes); ?>
 <div class="col-md-6">
            <div class="fg"><label> <?php echo $this->lang->line('name');?> </label>
			
              <input type="text"  name="name" placeholder="Name" value="<?php echo set_value('name'); ?>"><?php echo form_error('name'); ?></div>
              
			  
              <div class="fg"><label> <?php echo $this->lang->line('phone');?> / <?php echo $this->lang->line('mobile');?>: * </label>
              <input type="text" name="contact_no" maxlength="11" placeholder="Phone" value="<?php echo set_value('contact_no');?>"><?php echo form_error('contact_no');?></div>
			  
          </div>
          <div class="col-md-6">   <div class="fg"><label><?php echo $this->lang->line('email');?>: * </label>
              <input type="text"  name="email" placeholder="Email" value="<?php echo set_value('email');?>"><?php echo form_error('email');?></div>
              
			  
              <div class="fg"><label><?php echo $this->lang->line('booking_reference');?> : </label>
              <input type="text"  name="booking_no" placeholder="Booking Reference No" value="<?php echo set_value('booking_no');?>"></div></div>
			
		   
          <div class="col-md-12">    <div class="fg"><label> <?php echo $this->lang->line('message');?> </label>
            <textarea cols="" rows="" name="message" value="<?php echo set_value('booking_no');?>"></textarea><?php echo form_error('message');?> </div></div>
            
            

			
			<div class="col-md-12 padding">
				<input type="submit" name="submit" value="<?php echo $this->lang->line('submit');?>" class="cabs-btn">
			</div>

		<?php echo form_close();?>	
          </article>
        </div>
      </div>
      <div class="col-md-6">
	  
		
        <div class="right-side-cont">
      <?php if(isset($site_settings->contact_map) && $site_settings->contact_map != "") {?>
          <div class="services con">
           <div class="right-side-hed ">
		   
  <?php echo $this->lang->line('map');?>
   </div>
            <?php echo $site_settings->contact_map;?>
             
          </div>
          <?php } ?>
          <div class="services con">
           <div class="right-side-hed ">
  <?php echo $this->lang->line('address');?>
   </div>
            <strong><?php echo $site_settings->design_by;?></strong><br>
	<?php echo $site_settings->address.", ".$site_settings->city.", ".$site_settings->state.", ".$site_settings->country.", ".$site_settings->zip;?>
          </div>
        </div>
		
	
		
      </div>
    </div>
  </div>
</div>


<script type="text/javascript"> 
   (function($,W,D)
   {
      var JQUERY4U = {};
   
      JQUERY4U.UTIL =
      {
          setupFormValidation: function()
          {
              //Additional Methods			
   		
   $.validator.addMethod("lettersonly",function(a,b){return this.optional(b)||/^[a-z ]+$/i.test(a)},"<?php echo $this->lang->line('valid_name');?>");
   		
   		$.validator.addMethod("phoneNumber", function(uid, element) {
   			return (this.optional(element) || uid.match(/^([0-9]*)$/));
   		},"<?php echo $this->lang->line('valid_phone_number');?>");
		
		
		$.validator.addMethod("bookingrefno", function(uid, element) {
   			return (this.optional(element) || uid.match(/^\d{12}$/));
   		},"<?php echo $this->lang->line('valid_booking_no');?>");
   		
   		
   		//form validation rules
              $("#contact_form").validate({
                  rules: {
                      name: {
                          required: true,
						  lettersonly: true
                      },
   				contact_no: {
                          required: true,
						  phoneNumber: true,
						rangelength: [10, 11]
                      },
				email:{
					required: true,
					email: true
				},
				message:{
					required:true
				}
                  },
   			
   			messages: {
   				name: {
                          required: "<?php echo $this->lang->line('name_valid');?>"
                      },
   				contact_no: {
                          required: "<?php echo $this->lang->line('phone_valid');?>"
                      },
				email:{
					required: "<?php echo $this->lang->line('email_valid');?>"
				},
				message:{
					required: "<?php echo $this->lang->line('message_valid');?>"
				}
   			},
                  
                  submitHandler: function(form) {
                      form.submit();
                  }
              });
          }
      }
   
      //when the dom has loaded setup form validation rules
      $(D).ready(function($) {
          JQUERY4U.UTIL.setupFormValidation();
      });
   
   })(jQuery, window, document);
</script>

<style>#gmap_canvas {
    width: 91.5% !important;
}</style>
