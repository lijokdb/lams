<style>

#wt_enabled_table thead, #ct_incr_table thead {

	 background: none repeat scroll 0 0 #fafafa;
    font-size: 12px;

}

</style>
<?php

	error_reporting( ~E_NOTICE ); // avoid notice
	
	require_once 'dbconfig.php';

	
	if(isset($_POST['btnsave']))
	{
		
		$category_id = $_POST['category_id'];// gdsf
		$model = $_POST['model'];// gg
		$name = $_POST['name'];// gg
		$car_number_plate = $_POST['car_number_plate'];//gsg 
		$description = $_POST['description'];// gg
		$passengers_capacity = $_POST['passengers_capacity'];// gs
		$large_luggage_capacity = $_POST['large_luggage_capacity'];// dshds
		$small_luggage_capacity = $_POST['small_luggage_capacity'];// dhdhd
		$fuel_type = $_POST['fuel_type'];//hdh 
		$total_vehicles = $_POST['total_vehicles'];//hhd 
		$waiting_time = $_POST['waiting_time'];// hd
		$cost_type = $_POST['cost_type'];// hsh
		$ct_flat_min_dist_day = $_POST['ct_flat_min_dist_day'];// hdsh
		$ct_flat_min_cost_day = $_POST['ct_flat_min_cost_day'];//hsdh 
		$ct_flat_min_dist_night = $_POST['ct_flat_min_dist_night'];// hsh
		$ct_flat_min_cost_night = $_POST['ct_flat_min_cost_night'];// hsh
		
		$cost_starting_from = $_POST['cost_starting_from'];// dshds
		$status = $_POST['status'];// hshds
		
		$imgFile = $_FILES['image']['name'];
		$tmp_dir = $_FILES['image']['tmp_name'];
		$imgSize = $_FILES['image']['size'];
		
		
		if(empty($category_id)){
			$errMSG = "Please Enter category id.";
		}
		else if(empty($model)){
			$errMSG = "Please Enter model.";
		}
		
		else if(empty($name)){
			$errMSG = "Please Enter name.";
		}
		else if(empty($car_number_plate)){
			$errMSG = "Please Enter Your car number.";
		}
		else if(empty($description)){
			$errMSG = "Please Enter description.";
		}
		else if(empty($passengers_capacity)){
			$errMSG = "Please Enter passengers capacity.";
		}
		else if(empty($large_luggage_capacity)){
			$errMSG = "Please Enter large luggage capacity.";
		}
		else if(empty($small_luggage_capacity)){
			$errMSG = "Please Enter small luggage capacity.";
		}
		else if(empty($fuel_type)){
			$errMSG = "Please Enter fuel type.";
		}
		else if(empty($total_vehicles)){
			$errMSG = "Please Enter total vehicles.";
		}
		else if(empty($waiting_time)){
			$errMSG = "Please Enter waiting time.";
		}
		else if(empty($cost_type)){
			$errMSG = "Please Enter cost type.";
		}
		else if(empty($ct_flat_min_dist_day)){
			$errMSG = "Please Enter ct_flat_min_dist_day.";
		}
		else if(empty($ct_flat_min_cost_day)){
			$errMSG = "Please Enter ct_flat_min_cost_day.";
		}
		else if(empty($ct_flat_min_dist_night)){
			$errMSG = "Please Enter ct_flat_min_dist_night.";
		}
		else if(empty($ct_flat_min_cost_night)){
			$errMSG = "Please Enter ct_flat_min_cost_night.";
		}
		else if(empty($cost_starting_from)){
			$errMSG = "Please Enter cost_starting_from.";
		}
		else if(empty($status)){
			$errMSG = "Please Enter status.";
		}
		else if(empty($imgFile)){
			$errMSG = "Please Select Image File.";
		}
		else
		{
			$upload_dir = 'user_images/'; // upload directory
	
			$imgExt = strtolower(pathinfo($imgFile,PATHINFO_EXTENSION)); // get image extension
		
			// valid image extensions
			$valid_extensions = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions
		
			// rename uploading image
			$image = rand(1000,1000000).".".$imgExt;
				
			// allow valid image file formats
			if(in_array($imgExt, $valid_extensions)){			
				// Check file size '5MB'
				if($imgSize < 5000000)				{
					move_uploaded_file($tmp_dir,$upload_dir.$image);
				}
				else{
					$errMSG = "Sorry, your file is too large.";
				}
			}
			else{
				$errMSG = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";		
			}
		}
		
		
		// if no error occured, continue ....
		if(!isset($errMSG))
		{
			$stmt = $DB_con->prepare ("INSERT INTO vbs_vehicle(category_id, model, name, car_number_plate, description, passengers_capacity, large_luggage_capacity, small_luggage_capacity, fuel_type, total_vehicles, waiting_time, cost_type, ct_flat_min_dist_day, ct_flat_min_cost_day, ct_flat_min_dist_night, ct_flat_min_cost_night, image, cost_starting_from, status)VALUES(:category_id,:model,:name,:car_number_plate,:description,:passengers_capacity,:large_luggage_capacity,:small_luggage_capacity,:fuel_type,:total_vehicles,:waiting_time,:cost_type,:ct_flat_min_dist_day,:ct_flat_min_cost_day,:ct_flat_min_dist_night,:ct_flat_min_cost_night,:image,:cost_starting_from,:status)");
			
			$stmt->bindParam(':category_id',$category_id);
			$stmt->bindParam(':model',$model);
			$stmt->bindParam(':name',$name);
			$stmt->bindParam(':car_number_plate',$car_number_plate);
			$stmt->bindParam(':description',$description);
			$stmt->bindParam(':passengers_capacity',$passengers_capacity);
			$stmt->bindParam(':large_luggage_capacity',$large_luggage_capacity);
			$stmt->bindParam(':small_luggage_capacity',$small_luggage_capacity);
			$stmt->bindParam(':fuel_type',$fuel_type);
			$stmt->bindParam(':total_vehicles',$total_vehicles);
			$stmt->bindParam(':waiting_time',$waiting_time);
			$stmt->bindParam(':cost_type',$cost_type);
			$stmt->bindParam(':ct_flat_min_dist_day',$ct_flat_min_dist_day);
			$stmt->bindParam(':ct_flat_min_cost_day',$ct_flat_min_cost_day);
			$stmt->bindParam(':ct_flat_min_dist_night',$ct_flat_min_dist_night);
			$stmt->bindParam(':ct_flat_min_cost_night',$ct_flat_min_cost_night);
			$stmt->bindParam(':image',$image);
			$stmt->bindParam(':cost_starting_from',$cost_starting_from);
			$stmt->bindParam(':status',$status);
			if($stmt->execute())
			{
				$successMSG = "new record succesfully inserted ...";
				header("refresh:5;index.php"); // redirects image view page after 5 seconds.
			}
			else
			{
				$errMSG = "error while inserting....";
			}
		}
	}
?>

<?php $locale_info = localeconv(); ?>
    <div class="col-md-10 padding white right-p">
      <div class="content">
        <div class="col-md-12 padding-p-l">
          <div class="module">           
			
           <div class="main-hed"> 

			 <a href="/auth"></a>
			 
			 <?php if(isset($title)) echo " >> Vehicles Settings >> ".$title;?>
			 
			</div>
			
			
					
		   <div class="module-head">
		   
				 <h3> </h3>
				<a class="btn btn-primary add-btn" href="/vehicle_settings/vehicles">
				<i class="fa fa-list">&nbsp;</i></a>					
	 
		  </div>
		   
            <div class="module-body">
              <!---->			  
<form method="post" enctype="multipart/form-data" class="form-horizontal">
	    
	
	
 
     <div class="col-md-6">
    <div class="form-group">
    <label>Category</label>
        <input type="text" name="category_id" placeholder="Enter category_id" value="<?php echo $category_id; ?>" />
    </div>
    <div class="form-group">
    <label >name.</label>
        <input  type="text" name="name" placeholder="Enter name" value="<?php echo $name; ?>" />
    </div>
    <div class="form-group">
    	<label >model.</label>
        <input  type="text" name="model" placeholder="Your model" value="<?php echo $model; ?>" />
     </div>
    <div class="form-group">
    <label >Car Number.</label>
    <input  type="text" name="car_number_plate" placeholder="Enter car_number_plate" value="<?php echo $car_number_plate; ?>" />
     </div>
    <div class="form-group">
    <label >fuel type.</label>
       <input  type="text" name="fuel_type" placeholder="Enter fuel_type" value="<?php echo $fuel_type; ?>" />
    </div>
    <div class="form-group">
    	<label >Passengers Capacity.</label>
      <input  type="text" name="passengers_capacity" placeholder="Enter passengers_capacity" value="<?php echo $passengers_capacity; ?>" />
     </div>
    <div class="form-group">
   
    
   
    	<label >Large Luggage Capacity.</label>
        <input  type="text" name="large_luggage_capacity" placeholder="Enter large_luggage_capacity" value="<?php echo $large_luggage_capacity; ?>" />
     </div>
    <div class="form-group">
    <label >Small Luggage Capacity.</label>
        <input  type="text" name="small_luggage_capacity" placeholder="Enter small_luggage_capacity" value="<?php echo $small_luggage_capacity; ?>" />
         </div>
    <div class="form-group">
    <label>Profile Img.</label>
       <input class="input-group" type="file" name="image" accept="image/*" />
         </div>
    <div class="form-group">
    <label >description.</label></td>
       <input  type="text" name="description" placeholder="Enter description" value="<?php echo $description; ?>" /></div>
        </div>
         <!-- another div -->
                 <div class="col-md-6">

                   
    <div class="form-group">
   
    	<label >Total Vehicles.</label>
       <input  type="text" name="total_vehicles" placeholder="Enter total_vehicles" value="<?php echo $total_vehicles; ?>" />
        </div>
    <div class="form-group">
    <label >waiting time.</label>
      <input  type="text" name="waiting_time" placeholder="Enter waiting_time" value="<?php echo $waiting_time; ?>" />
      </div>
    
    
    
    
    
      	<div class="form-group">
                     <label>
                       cost starting from

                     </label>
                     <input type="text" name="starting_cost" value=""/>
					
                    </div>

					<div class="cost-type">
                   
					<div id="ct_flat_div" >
					<p id="ct_flat_text">* Set flat costs per <?php echo $site_settings->distance_type;?>.</p>
					<table width="100%">

					 <tr>
					<td></td>
					<td>Min. Distance (in )</td>
					<td>Min. Cost ()</td>
					</tr>
					<tr>
						<td> day</td>
						<td><input type="text" placeholder="" name="ct_flat_min_dist_day" id="ct_flat_min_dist_day" value=""></td>
						<td><input type="text" placeholder="" name="ct_flat_min_cost_day" id="ct_flat_min_cost_day" value=""></td>
					</tr>

					<tr>
						<td> night</td>
						<td><input type="text" placeholder="" name="ct_flat_min_dist_night" id="ct_flat_min_dist_night" value=""></td>
						<td><input type="text" placeholder="" name="ct_flat_min_cost_night" id="ct_flat_min_cost_night" value=""></td>
					</tr>            
										
					<tr>
					<td></td>
					<td>day time</td>
					<td>night time</td>
					</tr>
					<tr>
						<td> flatcost </td>
						<td><input type="text" placeholder="" name="day_flat_rate" id="day_flat_rate" value=""/></td>
						<td><input type="text" placeholder="" name="night_flat_rate" id="night_flat_rate" value=""/></td>
					</tr>
					</table>
					</div>
					
					

						
								
						
						</tbody>
		
						

					</table>
					</div>
					
					
					
					
					
					<div class="form-group">
					<label>status</label>
					
					options = array(
									'Active' => 'Active',
									'Inactive' => 'Inactive',
				

					</div>

                 </div>

				 
           
           
           
           
          <div class="col-md-6">  
           
         <span colspan="2"><button type="submit" name="btnsave" class="btn btn-default"></span>
        <span class="glyphicon glyphicon-save"></span> &nbsp; save
        </button>
     
   </div>
 
    
</form>
				 
            </div>
            
          </div>
        </div>
      </div>
    </div>

	
	