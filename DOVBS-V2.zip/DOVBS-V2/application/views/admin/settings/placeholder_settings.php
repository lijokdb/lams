<div class="col-md-10 padding white right-p">
   <div class="content">
      <?php echo $this->session->flashdata('message'); ?>
      <div class="main-hed"> 
         <a href="<?php echo site_url();?>/auth"><?php echo $this->lang->line('home');?></a>
         <?php if(isset($title)) echo " >> Master Settings >> ".$title;?>
      </div>
      <div class="col-md-6 padding-p-l">
         <div class="module">
            <div class="module-head">
               <h3><?php echo $title;?></h3>
            </div>

            <div class="module-body">
               <?php 
                  $attributes = array('name' => 'placeholder_settings_form', 'id' => 'placeholder_settings_form');
                  echo form_open('settings/placeholderSettings',$attributes) ;?>

               <div class="form-group">                    
                  <label><?php echo $this->lang->line('pick_point_placeholder');?></label>    
                  <input type="text" name="pick_point_placeholder" 
                     value= "<?php echo set_value('pick_point_placeholder', (isset($site_settings->pick_point_placeholder)) ? $site_settings->pick_point_placeholder : '');?>" />  
                  <?php echo form_error('pick_point_placeholder');?>
               </div>

			   <div class="form-group">                    
                  <label><?php echo $this->lang->line('drop_point_placeholder');?></label>    
                  <input type="text" name="drop_point_placeholder" 
                     value= "<?php echo set_value('drop_point_placeholder', (isset($site_settings->drop_point_placeholder)) ? $site_settings->drop_point_placeholder : '');?>" />  
                  <?php echo form_error('drop_point_placeholder');?>
               </div>

               <input type="hidden" value="<?php  if(isset($site_settings->id))
                  echo $site_settings->id;
                  ?>"  name="update_record_id" />

               <input type="submit" value="<?php echo $this->lang->line('update');?>" name="submit" />
               <?php echo form_close();?>
            </div>

         </div>
      </div>
   </div>
</div>
