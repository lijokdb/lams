<div class="wrapper">
<div class="container-fluid padding">
<div class="col-md-2 padding si-wi">
   <div class="sidebar">
      <div id='cssmenu'>
         <ul>
            <li <?php if(isset($active_class)){ if($active_class=="dashboard") echo 'class="active"'; }?>><a href="<?php echo site_url();?>/admin"><span><?php echo $this->lang->line('dashboard');?></span></a></li>
            <li <?php if(isset($active_class) && $active_class=="bookings") { echo 'class="has-sub active"'; } else { echo 'class="has-sub"'; } ?> >
               <a href="#"><span><?php echo $this->lang->line('bookings');?></span></a>
               <ul>
                  <li class="active"><a href="<?php echo site_url();?>/settings/bookings/Add"><?php echo $this->lang->line('add_booking');?></a></li>
                  <li><a href="<?php echo site_url();?>/settings/todayBookings"><span><?php echo $this->lang->line('today_bookings');?></span></a>
                  </li>
                  <li><a href="<?php echo site_url();?>/settings/searchBookings"><span><?php echo $this->lang->line('search_bookings');?></span></a>
                  </li>
                  <li><a href="<?php echo site_url();?>/settings/bookings"><span><?php echo $this->lang->line('all_bookings');?></span></a>
                  </li>
               </ul>
            </li>
            <li <?php if(isset($active_class) && $active_class=="vehicle") { echo 'class="has-sub active"'; } else { echo 'class="has-sub"'; } ?>>
               <a href="#"><span><?php echo $this->lang->line('vehicle_settings');?></span></a>
               <ul>
                  <li><a href="<?php echo site_url(); ?>/vehicle_settings/vehicles"><span><?php echo $this->lang->line('list_vehicles');?></span></a>
                  </li>
                  <li><a href="<?php echo site_url(); ?>/vehicle_settings/vehicles/Add"><span><?php echo $this->lang->line('add_vehicle');?></span></a>
                  </li>
                  <li><a href="<?php echo site_url();?>/settings/vehicleCategories"><span><?php echo $this->lang->line('vehicle_categories');?></span></a></li>
                  <li><a href="<?php echo site_url();?>/settings/vehicleFeatures"><span><?php echo $this->lang->line('vehicle_features');?></span></a></li>
               </ul>
            </li>
			 
			
			 
			 
            <li <?php if(isset($active_class) && $active_class=="airports") { echo 'class="has-sub active"'; } else { echo 'class="has-sub"'; } ?>>
               <a href="#"><span><?php echo $this->lang->line('airport_settings');?></span></a>
               <ul>
                  <li><a href="<?php echo site_url();?>/settings/airports"><span><?php echo $this->lang->line('list_airports');?></span></a></li>
                  <li><a href="<?php echo site_url();?>/settings/airports/Add"><span><?php echo $this->lang->line('add_airport');?></span></a></li>
               </ul>
            </li>
            <li <?php if(isset($active_class) && $active_class=="users") { echo 'class="has-sub active"'; } else { echo 'class="has-sub"'; } ?>>
               <a href="#"><span><?php echo $this->lang->line('users');?></span></a>
               <ul>
                  <li><a href="<?php echo site_url();?>/admin/customers"><span><?php echo $this->lang->line('list_customers');?></span></a>
                  </li>
                  <li><a href="<?php echo site_url();?>/admin/addCustomers"><span><?php echo $this->lang->line('add_customer');?></span></a>
                  </li>
                  <li><a href="<?php echo site_url(); ?>/admin/executives"><span><?php echo $this->lang->line('list_executives');?></span></a>
                  </li>
                  <li><a href="<?php echo site_url(); ?>/admin/addExecutives"><span><?php echo $this->lang->line('add_executive');?></span></a>
                  </li>
               </ul>
            </li>
            <li <?php if(isset($active_class) && $active_class=="masterSettings") { echo 'class="has-sub active"'; } else { echo 'class="has-sub"'; } ?>>
               <a href="#"><span><?php echo $this->lang->line('master_settings');?></span></a>      
               <ul>
                  <li><a href="<?php echo site_url();?>/settings/siteSettings"><span><?php echo $this->lang->line('site_settings');?></span></a></li>
                  <li><a href="<?php echo site_url();?>/settings/testimonials"><span><?php echo $this->lang->line('testimonial_settings');?></span></a></li>
                  <li><a href="<?php echo site_url();?>/settings/emailSettings"><span><?php echo $this->lang->line('email_settings');?></span></a></li>
                  <li><a href="<?php echo site_url();?>/settings/paypalSettings"><span><?php echo $this->lang->line('paypal_settings');?></span></a></li>
                  <li><a href="<?php echo site_url();?>/settings/packageSettings"><span><?php echo $this->lang->line('hourly_package_settings');?></span></a></li>
                  <li><a href="<?php echo site_url();?>/settings/waitings"></span><?php echo $this->lang->line('waiting_time_settings');?></span></a></li>
                  <li><a href="<?php echo site_url();?>/settings/reasonsToBook"></span><?php echo $this->lang->line('reasons_to_book_with_us');?></span></a></li>
                  <li><a href="<?php echo site_url();?>/settings/socialNetworks"></span><?php echo $this->lang->line('social_networks');?></span></a></li>
                  <li><a href="<?php echo site_url();?>/settings/seoSettings"></span><?php echo $this->lang->line('seo_settings');?></span></a></li>
                  <li><a href="<?php echo site_url();?>/settings/themeSettings"></span><?php echo $this->lang->line('theme_settings');?></span></a></li>
				  <li><a href="<?php echo site_url();?>/settings/placeholderSettings"></span><?php echo $this->lang->line('placeholder_settings');?></span></a></li>
               </ul>
            </li>
            <li <?php if(isset($active_class) && $active_class=="page") echo 'class="active"';?>><a href="<?php echo site_url();?>/settings/aboutUs"><span><?php echo $this->lang->line('dynamic_pages');?></span></a></li>
            <li <?php if(isset($active_class)){ if($active_class=="faq") echo 'class="active"'; }?>><a href="<?php echo site_url();?>/settings/faqs"><span><?php echo $this->lang->line('faqs');?></span></a></li>
            <li <?php if(isset($active_class) && $active_class=="report") { echo 'class="has-sub active"'; } else { echo 'class="has-sub"'; } ?>>
               <a href="#"><span><?php echo $this->lang->line('reports');?></span></a>
               <ul>
                  <li><a href="<?php echo site_url();?>/reports/overallVehicles"><span><?php echo $this->lang->line('overall_vehicles');?></span></a>
                  </li>
                  <li><a href="<?php echo site_url();?>/reports/payments"><span><?php echo $this->lang->line('payments');?></span></a>
                  </li>
               </ul>
            </li>
         </ul>
      </div>
   </div>
</div>