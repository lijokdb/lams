   </div>

    <!--/.span9--> 

  </div>

<div class="footer">

      <div class="container"> 
	   <div class="copyright-left">
         <?php if(isset($site_settings->rights_reserved_content)) { ?>
          <?php echo $site_settings->rights_reserved_content;?>
        <?php } ?>
		<p style="float:right">Page rendered in {elapsed_time} seconds. </p>
        </div>
	  </div>

    </div>

<script src="<?php echo base_url();?>/assets/system_design/scripts/jquery.min.js"></script> 



 <script src="<?php echo base_url();?>assets/system_design/scripts/timepicki.js"></script>
    <script>
    	$('#timepicker1').timepicki({increase_direction:'up'});
		$('#timepicker2').timepicki({increase_direction:'up'});
 	 
    </script>

<!--Date Table--> 

<?php if(in_array("datatable",$css_type)) { ?>

<script type="text/javascript" language="javascript" src="<?php echo base_url();?>/assets/system_design/scripts/jquery.dataTables.js"></script> 

<script type="text/javascript" language="javascript" class="init">



$(document).ready(function() {

	$('#example').dataTable();

	$('.example').dataTable();

} );



	</script> 

	<?php } ?>

	<!--Date Table--> 

		

	<script src="<?php echo base_url();?>/assets/system_design/scripts/BeatPicker.min.js"></script> 

    <script src="<?php echo base_url();?>/assets/system_design/scripts/sidemenu-script.js"></script>

    

	<script src="<?php echo base_url();?>/assets/system_design/scripts/bootstrap.min.js" type="text/javascript"></script> 

	

	<!--Calendar--> 

	<?php if(in_array("calendar",$css_type)) { ?>

	<script src="<?php echo base_url();?>/assets/system_design/scripts/responsive-calendar.js"></script> 

	<script type="text/javascript">

      $(document).ready(function () {

        $(".responsive-calendar").responsiveCalendar({

          time: '2013-05',

          events: {

            "2013-04-30": {"number": 5, "url": "http://w3widgets.com/responsive-slider"},

            "2013-04-26": {"number": 1, "url": "http://w3widgets.com"}, 

            "2013-05-03":{"number": 1}, 

            "2013-06-12": {}}

        });

      });

    </script>

	<?php } ?>

	<!--Form elements-->

	<?php if(in_array("form",$css_type)) { ?>

	

	 <link href="<?php echo base_url();?>/assets/system_design/css/uniform.default.css" rel="stylesheet" media="screen">

        <link href="<?php echo base_url();?>/assets/system_design/css/chosen.min.css" rel="stylesheet" media="screen">

 

        <script src="<?php echo base_url();?>/assets/system_design/scripts/jquery.uniform.min.js"></script>

        <script src="<?php echo base_url();?>/assets/system_design/scripts/chosen.jquery.min.js"></script>

 

		<script type="text/javascript" src="<?php echo base_url();?>/assets/system_design/scripts/jquery.validate.min.js"></script>

		<script src="<?php echo base_url();?>/assets/system_design/scripts/form-validation.js"></script>
 
 
 <?php if($gmaps == "true") { ?>
 <script src="http://maps.googleapis.com/maps/api/js?sensor=false&amp;libraries=places"></script>
 <!--script src="<?php echo base_url();?>assets/system_design/scripts/jquery.min.js"></script--> 
 <script src="<?php echo base_url();?>assets/system_design/scripts/jquery.geocomplete.js"></script>
 <script src="<?php echo base_url();?>assets/system_design/scripts/logger.js"></script>
 <script src="<?php echo base_url();?>assets/system_design/scripts/gmap3.js"></script>
<?php } ?>

         <script>



 jQuery(document).ready(function() {  

 FormValidation.init();
	 <?php if($gmaps == "true") { ?> 
	 
	 Pickpoint = '';
	Droppoint = '';
	Pickup_time = '';
	 
	 /* On Change Event of Time */
	   $('.action-next, .action-prev').click(function() {

			$('#no_repeat').val('1');
			setTimeout(
			  function() 
			  {

					if(($('#local_pick').val()!='' && $('#local_drop').val()!='')) {
						Pickpoint = $('#local_pick').val();	
						Droppoint = $('#local_drop').val();
						Pickup_time = $('#timepicker1').val();
						page = $('#local_drop').attr("alt");
					}

					if(Pickpoint!='' && Droppoint!='')
					get_map(Pickpoint,Droppoint,Pickup_time,page);
					$('#journey_details').fadeIn(1500);

			  }, 500);

		});

	$(".location").geocomplete({
          country: '<?php echo $site_settings->site_country;?>' 
	}).bind("geocode:result", function(event, result){
		if($('#no_repeat').val() == 1)
			$(this).trigger("geocode");

   		$(this).val(JSON.stringify(result.formatted_address));		

   			if(($('#local_pick').val()!='' && $('#local_drop').val()!='')) {
				Pickpoint = $('#local_pick').val();	
				Droppoint = $('#local_drop').val();
				Pickup_time = $('#timepicker1').val();
				page = $('#local_drop').attr("alt");
			}

			if(Pickpoint!='' && Droppoint!='') {

				if($('#no_repeat').val() == 1) {
					get_map(Pickpoint,Droppoint,Pickup_time,page);		
					$('#journey_details').fadeIn(1500);
				}				
			}
     });
	<?php } ?>
			
		
	});


	function numberWithCommas(x) {
		var parts = x.toString().split(".");
		parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
		return parts.join(".");
	}

	function get_map(PickLocation,DropLocation,Pickup_time,page) {
	if($('#no_repeat').val() == 1) {
$("#dummy").gmap3({ 
 clear: {},

  getroute:{
    options:{
        origin:PickLocation,
        destination:DropLocation,
        travelMode: google.maps.DirectionsTravelMode.DRIVING,
		/*ENABLE IT IF MILES*/
		<?php if($site_settings->distance_type=='Mi') {?>
		unitSystem: google.maps.UnitSystem.IMPERIAL,
		<?php } ?>		
    },
    callback: function(results) {

	var dist = numberWithCommas(Math.round(parseFloat(results.routes[0].legs[0].distance.value)/1000));

   	var dist0 = dist+" "+(results.routes[0].legs[0].distance.text).split(" ")[1];

	var time = results.routes[0].legs[0].duration.text+" (Approx)";

	$('#distance').val(dist0+"  "+time);

			$.ajax({

			 type: 'POST',

			 url: "<?php echo site_url();?>/bookingsystem/getVechicles",
			 data: '<?php echo $this->security->get_csrf_token_name();?>=<?php echo $this->security->get_csrf_hash();?>&distance='+dist+','+'&Pickup_time='+Pickup_time+'&page='+page+'&journey_time='+time,
			 cache: false,			 
			 success: function(data) {
				 //alert(data);
				 if(data != 0) {
					$('#cars_data_list').html(data);
				} else {
				  $('#cars_data_list').html('<p class="no-vehiclez">Sorry, No Vehicles Available.</p>');
				}
				$('#cars_data_list').show();
				$('#no_repeat').val('0');
			 }		  		
			
			});
	}
  }
});
}
}
			
			
			
			
	 		$(function() {

			 

				$(".uniform_on").uniform();

				$(".chzn-select").chosen();

			 

	 

			});

			
		
        
  $("#return_journey").click(function(){
          
		   
	
	if($('#return_journey').is(":checked")) {
		
		$("#waiting_time_div").fadeIn(500);
		total = parseFloat($("#car_cost").val())*2;
		$("#total_cost").val(total);
	
	} else {
      
		$("#waiting_time_div").fadeOut(500);
		value = parseFloat($("#car_cost").val());
		$("#total_cost").val(value);
		
	}
        
   });
 

 $("#waiting_time").change(function(){
	
	ins = $('#waiting_time').val().split(' ');
	
	total = parseFloat($("#car_cost").val()*2)+parseFloat(ins[1]);
	
	$("#total_cost").val(total);
	
  });
 
 function setActive(id) {
		
		numid = id.split('_')[1];
		$('#waitnreturn').fadeIn(500);
		carCost = $('#cab_'+numid).val();	
		cost = (carCost.split("_")[1]);
		$('#car_cost').val(cost);
		$("#total_cost").val(cost); 
		
}

        </script>

		<?php } ?>

</body>

