<div class="col-md-10 padding white right-p">
   <div class="content">
     <div class="col-md-12 padding-p-l">
         <?php echo $this->session->flashdata('message');?>              
         <div class="module">
            <div class="main-hed">
               <a href="<?php echo site_url();?>/auth"><?php echo $this->lang->line('home');?></a> 
               <?php if(isset($title)) echo " >> Dashboard >> ".$title;?>
            </div>
            <div class="module-head">
               <h3><?php echo $title;?></h3>
            </div>
           <div class="module-body">
             <div class="col-md-8 padding-p-l">
                  <div class="panel panel-default">
                     <div class="panel-body padding-p-l padding-p-r">
                        <table class="table table-striped">
                           <?php foreach($users as $row):?>
                           <tr>
                              <!--<td colspan="4"> 
                                 <img src="<?php //echo base_url(); ?>/assets/system_design/images/profile-img.jpg"/>
                                 
                                 </td>-->
                           </tr>
                           <tr>
                              <td><strong> : </strong></td>
                              <td>&nbsp;</td>
                              <td> <strong><?php echo $this->lang->line('phone');?> :</strong> </td>
                              <td>&nbsp;</td>
                           </tr>
                           <tr>
                              <td> <strong> : </strong></td>
                              <td>&nbsp;</td>
                              <td> <strong>: </strong></td>
                              <td>&nbsp;</td>
                           </tr>
                           <tr>
                              <td> <strong>:</strong> </td>
                              <td>&nbsp;</td>
                              <td> <strong>  :</strong> </td>
                              <td>&nbsp;</td>
                           </tr>
                        </table>
                     </div>
                  </div>
				  
                <div class="form-group"></div>
               </div>
               </div>
         </div>
      </div>
   </div>
</div>
</div>