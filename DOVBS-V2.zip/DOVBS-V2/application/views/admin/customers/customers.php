<div class="col-md-10 padding white right-p">
   <div class="content">
      <div class="main-hed">
         <a href="<?php echo site_url();?>/auth"><?php echo $this->lang->line('home');?></a> 
         <?php if(isset($title)) echo " >> Users >> ".$title;?>
      </div>
      <?php echo $this->session->flashdata('message'); ?>
      <div class="col-md-12 padding-p-r">
         <div class="module">
            <div class="module-head">
               <h3><?php echo $title;?></h3>
              <?php if($this->ion_auth->is_admin()) {?>
			  <a class="btn btn-primary add-btn" href="<?php echo site_url(); ?>/admin/addCustomers">
               <i class="fa fa-plus">&nbsp;<?php echo $this->lang->line('add');?></i></a>
			   <?php } ?>
            </div>
            <div class="module-body">
               <table id="example" class="cell-border example" cellspacing="0" width="100%">
                  <thead>
                     <tr>
                        <th>#</th>
                        <td><?php echo $this->lang->line('first_name');?></td>
                        <td><?php echo $this->lang->line('last_name');?></td>
                        <td><?php echo $this->lang->line('email');?></td>
                        <td><?php echo $this->lang->line('phone');?></td>
                        <td><?php echo $this->lang->line('password');?></td>
                         <td><?php echo $this->lang->line('status');?></td>
						<?php if($this->ion_auth->is_admin()) {?>
                        <th><?php echo $this->lang->line('action');?></th>
						<?php } ?>
                     </tr>
                  </thead>
                  <tfoot>
                     <tr>
                        <th>#</th>
                       <td><?php echo $this->lang->line('first_name');?></td>
                        <td><?php echo $this->lang->line('last_name');?></td>
                        <td><?php echo $this->lang->line('email');?></td>
                        <td><?php echo $this->lang->line('phone');?></td>
                        <td><?php echo $this->lang->line('password');?></td>
                         <td><?php echo $this->lang->line('status');?></td>
                        <?php if($this->ion_auth->is_admin()) {?>
                        <th><?php echo $this->lang->line('action');?></th>
						<?php } ?>
                     </tr>
                  </tfoot>
                  <tbody>
                     <?php 
                        $i=1;
                        foreach($customers as $row):?>
                     <tr>
                        <td><?php echo $i; $i++;?></td>
                        <td><?php echo $row->first_name;?></td>
                        <td><?php echo $row->last_name;?></td>
                        <td><?php echo $row->email;?></td>
                        <td><?php echo $row->phone;?></td>
                        <td><?php echo $row->password;?></td>
                         <td><?php echo $row->status;?></td>
                        <?php if($this->ion_auth->is_admin()) {?>
						<td>
                        <a class="btn btn-warning" type="button" href="<?php echo site_url(); ?>/settings/customers/Edit/<?php echo $row->id?>"><i class="fa fa-edit"></i></a>
                        <a class="btn btn-danger" data-toggle="modal" data-target="#myModal" onclick="changeDeleteId(<?php echo $row->id;?>)"><i class="fa fa-trash"></i></a>                        </td>
						<?php } ?>
                     </tr>
                     <?php endforeach; ?>
                  </tbody>
               </table>
            </div>
         </div>
      </div>
      <!--/.module--> 
   </div>
   <!--/.content--> 
</div>
<!-- Modal -->
<?php if($this->ion_auth->is_admin()) {?>
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="myModalLabel"><?php echo $this->lang->line('warning');?></h4>
         </div>
         <div class="modal-body">
            <?php echo $this->lang->line('sure_delete');?>
         </div>
         <div class="modal-footer">
            <a type="button" class="btn btn-default" id="delete_no" href=""><?php echo $this->lang->line('yes');?></a>
            <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo $this->lang->line('close');?></button>
         </div>
      </div>
   </div>
</div>
<script>
   function changeDeleteId(x) {
   	var str = "<?php echo site_url(); ?>/admin/deleteCustomer/Delete/" + x;
       $("#delete_no").attr("href",str);
   }
</script>
<?php } ?>