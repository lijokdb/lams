<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');
class Welcome extends MY_Controller
{
	/*
	| -----------------------------------------------------
	| PRODUCT NAME: 	DIGI VEHICLE BOOKING SYSTEM (DVBS)
	| -----------------------------------------------------
	| AUTHOR:			DIGITAL VIDHYA TEAM
	| -----------------------------------------------------
	| EMAIL:			digitalvidhya4u@gmail.com
	| -----------------------------------------------------
	| COPYRIGHTS:		RESERVED BY DIGITAL VIDHYA
	| -----------------------------------------------------
	| WEBSITE:			http://digitalvidhya.com
	|                   http://codecanyon.net/user/digitalvidhya
	| -----------------------------------------------------
	|
	| MODULE: 			Welcome
	| -----------------------------------------------------
	| This is welcome module controller file.
	| -----------------------------------------------------
	*/
	public function __construct()
	{
		parent::__construct();

		// To use site_url and redirect on this controller.
		//$this->load->helper('digiemail');
		
		$this->form_validation->set_error_delimiters(
		$this->config->item('error_start_delimiter', 'ion_auth'), 
		$this->config->item('error_end_delimiter', 'ion_auth')
		);
	}

	function index()
	{
		redirect('auth', 'refresh');
	}

	function onlineBooking()
	{
		$this->data['waiting'] 			= $this->db->get('waitings')->result();
		$waiting_times 					= $this->base_model->run_query(
		"SELECT * FROM vbs_waitings where status='Active'"
											);

		$waiting_options 				= array(
												'0.0_No ' => 'No Waiting Time'
												);
		foreach($waiting_times as $row) 
		$waiting_options[$row->cost . "_" . $row->waiting_time . " Mins"] 	
										= $row->waiting_time . " Mins (" . $row->cost . ")";
		$this->data['waiting_options'] 	= $waiting_options;
 
		$this->data['airports'] 		= $this->db->get_where(
											'vbs_airports', 
											array('status' => 'active'))->result();
		$this->data['css_type'] 		= array(
												"form",
												"onlinebooking"
												);
		$this->data['heading'] 			= $this->lang->line('online_booking');
		$this->data['sub_heading'] 		= "Online Booking";
		$this->data['bread_crumb'] 		= true;
		$this->data['active_class'] 	= "onlinebooking";
		$this->data['title'] 			= $this->lang->line('online_booking');
		$this->data['content'] 			= 'site/online-booking';
		$this->_render_page('templates/site_template', $this->data);
	}

	function passengerDetails()
	{	
		if ($this->input->post()) {
			// echo "<pre>"; print_r($this->input->post()); die();
			if($this->input->post('check_cars') == "0") {
				$this->prepare_flashmessage("No cars Available for given locations" , 1);
					redirect('welcome/onlineBooking');
			}
			$this->data['journey_details'] = $this->input->post();
			$this->session->unset_userdata('journey_details');
			$this->session->set_userdata('journey_details', $this->input->post());
			if ($this->ion_auth->logged_in()) {
				$this->data['user'] 	 = $this->db->get_where(
				$this->db->dbprefix('users') , 
				array('id' => $this->ion_auth->get_user_id())
				)->result_array() [0];
				$this->data['content'] = 'site/passenger-details';
			}
			else {
				$this->data['content'] = 'site/login-details';
			}
		}
		else {
			if ($this->ion_auth->logged_in()) {
				$this->data['user'] = $this->db->get_where($this->db->dbprefix('users') , 
				array('id' => $this->ion_auth->get_user_id()))->result_array() [0];
			}
			$this->data['journey_details'] 	= $this->session->userdata('journey_details');
			$this->data['content'] 			= 'site/passenger-details';
			}

		$this->data['css_type'] 			= array("form", "datatable");
		$this->data['heading'] 				= $this->lang->line('passenger_details');
		$this->data['sub_heading'] 			= "Passenger Details";
		$this->data['bread_crumb'] 			= TRUE;
		$this->data['title'] 				= $this->lang->line('passenger_details');
		$this->_render_page('templates/site_template', $this->data);
	}

	function payment()
	{
		if ($this->input->post()) {
			$this->session->unset_userdata('user');
			$this->data['user'] = $this->input->post();
			$this->session->set_userdata('user', $this->input->post());
		}
	  
		$this->data['journey_details'] 		= $this->session->userdata('journey_details');
		$this->data['title'] 				= $this->lang->line('payment_details');
		$this->data['css_type'] 			= array("form", "datatable");
		$this->data['heading'] 				= $this->lang->line('payment_details');
		$this->data['sub_heading'] 			= "Payment Details";
		$this->data['bread_crumb'] 			= true;
		$this->data['content'] 				= 'site/payment';
		$this->_render_page('templates/site_template', $this->data);
	}
	
	// FUNCTION FOR CONTACT US
	function contactUs()
	{
		$this->data['message'] 				= "";
		if ($this->input->post()) {
			
			// form validations
			$this->form_validation->set_rules('name', 'Name', 'required|xss_clean');
			$this->form_validation->set_rules('contact_no', 'Phone number', 'required|xss_clean');
			$this->form_validation->set_rules('email', 'Email', 'required|xss_clean');
			$this->form_validation->set_rules('booking_no', 'Booking Number', 'trim|xss_clean');
			$this->form_validation->set_rules('message', 'Message', 'xss_clean');
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			if ($this->form_validation->run() == TRUE) {

				/* $site_settings_rec = $this->db->get('vbs_site_settings')->result() [0];
				$config = Array(
					'protocol' => 'smtp',
					'smtp_host' => 'ssl://smtp.googlemail.com',
					'smtp_port' => 465,
					'smtp_user' => $site_settings_rec->portal_email, // change it to yours
					'smtp_pass' => '*****', // change it to yours
					'mailtype' => 'html',
					'charset' => 'iso-8859-1',
					'wordwrap' => TRUE
				);
				$this->data['info'] 		= $this->input->post();
				$message 					= $this->load->view(
											'email_format.php', 
											$this->data, 
											TRUE
											);

				$this->load->library('email', $config);
				$this->email->set_newline("\r\n");
				$this->email->from($site_settings_rec->portal_email); // change it to yours
				$this->email->reply_to($this->input->post('email'));
				$this->email->to($site_settings_rec->portal_email); // change it to yours
				$this->email->subject('Digital vehicle booking system query');
				$this->email->message($message);
				if ($this->email->send()) {
					$message 			= $this->lang->line('email_received');
					$this->email->set_newline("\r\n");
					$this->email->from($site_settings_rec->portal_email); // change it to yours
					$this->email->to($this->input->post('email'));
					$this->email->subject('acknowledgement - Digital vehicle booking system');
					$this->email->message($message);
					$this->email->send();
					$this->prepare_flashmessage($this->lang->line('email_sent_successfully_we_will_contact_you_as_soon_as_possible'), 0);
					redirect('welcome/contactUs', 'refresh');
				}
				else {
					$this->prepare_flashmessage($this->lang->line('unable_to_send_email'), 1);
					redirect('welcome/contactUs', 'refresh');
				} */
				
				
				$site_settings_rec = $this->db->get('vbs_site_settings')->result() [0];
				
				$this->data['info'] 		= $this->input->post();
				$message 					= $this->load->view(
											'email_format.php', 
											$this->data, 
											TRUE
											);

				$from = $this->input->post('email');
				
				$to = $site_settings_rec->portal_email;
				
				$sub = $this->config->item('site_title', 'ion_auth') . ' - ' . $this->lang->line('contact_query');
				
				if ( sendEmail($from, $to, $sub, $message) ) {

				$this->data['ack_info'] = array('name' => $this->input->post('name'), 'msgBody' => $this->lang->line('email_received'));
					$message 				= $this->load->view(
											'ack_email_format.php', 
											$this->data, 
											TRUE
											);
					
					$from    = $site_settings_rec->portal_email;
					
					$to      = $this->input->post('email');
					
					$sub     = $this->config->item('site_title', 'ion_auth') . ' - ' . $this->lang->line('acknowledgement');

					sendEmail($from, $to, $sub, $message);
					
					$this->prepare_flashmessage(
					$this->lang->line('email_sent_successfully_we_will_contact_you_as_soon_as_possible'), 0);
					redirect('welcome/contactUs', 'refresh');
				}
				else {
			$this->prepare_flashmessage($this->lang->line('unable_to_send_email'), 1);
//echo "<pre>";print_r($this->email->print_debugger());die();
					redirect('welcome/contactUs', 'refresh');
				}
			}
		}
		$this->data['css_type'] 			= array("form");
		$this->data['title'] 				= $this->lang->line('contact_us');
		$this->data['heading'] 				= $this->lang->line('contact_us');
		$this->data['active_class'] 		= "contactus";
		$this->data['sub_heading'] 			= $this->lang->line('contact_us');
		$this->data['bread_crumb'] 			= true;
		$this->data['content'] 				= 'site/contact_us';
		$this->_render_page('templates/site_template', $this->data);
	}

	function paymentConfirmation()
	{
		if ($this->input->post()) {

			$payment_mode 					= $this->input->post();
			if($this->session->userdata('journey_details')['booking_ref'] != "") {
			$this->data['journey_details'] 	= $this->session->userdata('journey_details');
			$this->data['user'] 			= $this->session->userdata('user');
			$this->data['payment_mode'] 	= $this->input->post('radiog_dark');
			if (
			$this->ion_auth->logged_in() && 
			$this->ion_auth->is_member()
			) 
			$inputdata['user_id'] 			= $this->ion_auth->get_user_id();
			$inputdata['booking_ref'] 		= $this->data['journey_details']['booking_ref'];
			$inputdata['pick_date'] 		= date('Y-m-d', strtotime($this->data['journey_details']['pick_date']));
			$inputdata['pick_time'] 		= $this->data['journey_details']['pick_time'];
			$inputdata['pick_point'] 		= $this->data['journey_details']['pick_up'];
			$inputdata['drop_point'] 		= $this->data['journey_details']['drop_of'];
			$dis_info 						= explode(
											" ", 
											$this->data['journey_details']['total_distance']
											);
			$vehicle_id 					= explode(
											"_", 
											$this->data['journey_details']['radiog_dark']
											);
			$inputdata['distance'] 			= $dis_info[0];
			$inputdata['distance_type'] 	= $this->config->item('site_settings')->distance_type;
			$inputdata['vehicle_selected'] 	= $vehicle_id[0];
			$inputdata['cost_of_journey'] 	= $this->data['journey_details']['total_cost'];
			$inputdata['payment_type'] 		= $payment_mode['radiog_dark'];
			if ($inputdata['payment_type'] == "cash") 
				$inputdata['payment_received'] = "0";
			$inputdata['is_conformed'] 		= "pending";
			$inputdata['bookdate'] 			= date('Y-m-d');
			$inputdata['registered_name'] 	= $this->data['user']['username'];
			$inputdata['phone'] 			= $this->data['user']['phone'];
			$inputdata['email'] 			= $this->data['user']['email'];
			$inputdata['info_to_drivers'] 	= $this->data['user']['information'];
			$inputdata['package_type'] 		= $this->data['journey_details']['package_type'];
			if ($inputdata['payment_type'] == "paypal") {
				$this->session->set_userdata('bookinginfo', $inputdata);
				redirect('payment/paynow');
			}

			$table 							= "bookings";
			$this->base_model->insert_operation($inputdata, $table);  
			if (1) {

				/* Send Booking Mail to User and Admin */
				$site_settings_rec = $this->db->get('vbs_site_settings')->result() [0];

				$message 					= $this->load->view(
											'booking_confirmation_email.php', 
											$this->data, 
											TRUE
											);

				$from = $inputdata['email'];

				$to = $site_settings_rec->portal_email;

				$sub = $this->lang->line('booking_ref').": ".$inputdata['booking_ref'];

				if ( sendEmail($from, $to, $sub, $message) ) {

					$from    = $site_settings_rec->portal_email;

					$to      = $inputdata['email'];

					$sub = $this->lang->line('booking_ref').": ".$inputdata['booking_ref'];

					sendEmail($from, $to, $sub, $message);
				}

				$this->session->unset_userdata('bookinginfo');
				$this->session->unset_userdata('user');
				$this->session->unset_userdata('journey_details');
				$this->data['css_type'] 	= array("form");
				$this->data['title'] 		= 'Booking Confirmation';
				$this->data['heading'] 		= "Booking Confirmation";
				$this->data['sub_heading'] 	= "Booking Confirmation";
				$this->data['bread_crumb'] 	= TRUE;
				$this->data['content'] 		= 'site/payment_confirmation';
				$this->_render_page('templates/site_template', $this->data);
			}
			
			} else redirect('/');
		}
	    else {
			redirect('/');
		}
	}  

	function faqs()
	{
		$faqs = $this->db->get_where('faqs', array('status' => 'Active'))->result();
		$this->data['faqs'] 				= $faqs;
		$this->data['css_type'] 			= array("form");
		$this->data['title'] 				= 'FAQs';
		$this->data['heading'] 				= "FAQs";
		$this->data['sub_heading'] 			= "FAQs";
		$this->data['active_class'] 		= "faqs";
		$this->data['bread_crumb'] 			= TRUE;
		$this->data['content'] 				= 'site/faqs';
		$this->_render_page('templates/site_template', $this->data);
	}

	function testimonials()
	{
		$testimonials 						= $this->db->get_where(
											'testimonials_settings', 
											array('status' => 'Active')
											)->result();
		$this->data['testimonials'] 		= $testimonials;
		$this->data['css_type'] 			= array("form");
		$this->data['title'] 				= 'Testimonials';
		$this->data['heading'] 				= "Testimonials";
		$this->data['sub_heading'] 			= "Testimonials";
		$this->data['active_class'] 		= "Testimonials";
		$this->data['bread_crumb'] 			= TRUE;
		$this->data['content'] 				= 'site/testimonials';
		$this->_render_page('templates/site_template', $this->data);
	}

	function themes()
	{
		$this->data['css_type'] 			= array("form");
		$this->data['title'] 				= 'Testimonials';
		$this->data['heading'] 				= "Testimonials";
		$this->data['sub_heading'] 			= "Testimonials";
		$this->data['active_class'] 		= "Testimonials";
		$this->data['bread_crumb'] 			= TRUE;
		$this->load->view('site/theame');
	}
	
	function download_app($param1='')
	{
	
		$this->load->helper('download');
	//	echo "<pre>"; print_r($this->config->item('site_settings')); die();
		if($param1!='') {
			if ($param1=='android') {
				$path = base_url()."uploads/mobileapp_files/".$this->config->item('site_settings')->android_filename; 
				$data = file_get_contents($path);
				$name = 'android.apk';
				force_download($name, $data);
			}
			elseif ($param1=='ios') {
				$path = base_url()."uploads/mobileapp_files/".$this->config->item('site_settings')->ios_filename; 
				$data = file_get_contents($path);
				$name = 'ios.ipa';
				force_download($name, $data);
			}
		}
		
	}
}
/* End of file Welcome.php */
/* Location: ./application/controllers/Welcome.php */