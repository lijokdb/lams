<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Users extends MY_Controller
{
	/*
	| -----------------------------------------------------
	| PRODUCT NAME: 	DIGI VEHICLE BOOKING SYSTEM (DVBS)
	| -----------------------------------------------------
	| AUTHOR:			DIGITAL VIDHYA TEAM
	| -----------------------------------------------------
	| EMAIL:			digitalvidhya4u@gmail.com
	| -----------------------------------------------------
	| COPYRIGHTS:		RESERVED BY DIGITAL VIDHYA
	| -----------------------------------------------------
	| WEBSITE:			http://digitalvidhya.com
	|                   http://codecanyon.net/user/digitalvidhya
	| -----------------------------------------------------
	|
	| MODULE: 			Users
	| -----------------------------------------------------
	| This is users module controller file.
	| -----------------------------------------------------
	*/
	function __construct()
	{
		parent::__construct();
	
		if(!$this->ion_auth->logged_in() || $this->ion_auth->is_admin() || $this->ion_auth->is_executive())
		   redirect('auth');
	
	}

	function index()
	{
		if (!$this->ion_auth->logged_in() && !$this->ion_auth->is_member()) 
			redirect('auth', 'refresh');
			
		$waiting_times 						= $this->base_model->run_query(
												"SELECT * FROM vbs_waitings"
												);

		$this->db->order_by("image", "random");
		$this->data['vehicles'] 			= $this->db->get('vbs_vehicle', 4)->result();
		$waiting_options = array( "0 0" => $this->lang->line('select_waiting_time'));
		foreach($waiting_times as $row) $waiting_options[$row->waiting_time . "Mins " . $row->cost] = $row->waiting_time . " Mins (" . $row->cost . ")";
		$this->data['waiting_options'] 		= $waiting_options;
		$this->data['country_code'] 		= "in";

		$site_settings = $this->base_model->run_query("SELECT * FROM vbs_site_settings");
		if (count($site_settings) > 0) 
			$this->data['site_settings'] 	= $site_settings[0];
		else $this->data['site_settings'] 	= array();
		
		$this->data['airports'] = $this->db->get_where($this->db->dbprefix('airports') , array(
				'status' => 'active'
			))->result();
		$this->data['css_type'] 			= array("homebooking");
		$this->data['bread_crumb'] 			= false;
		$this->data['title'] 				= $this->lang->line('welcome') . 
											" " . $this->lang->line('DVBS');
		$this->data['content'] 				= 'site/index';
		$this->_render_page('templates/site_template', $this->data);
	}

	function myBookings($param = '', $param1 = '', $param2 = '', $param3 = '')
	{
		if (!$this->ion_auth->logged_in() && !$this->ion_auth->is_member()) 
			redirect('auth', 'refresh');
		if ($param == "Cancel") {
			$table_name 					= "bookings";
			$where['id'] 					= $param1;
			$cond 							= "id";
			$cond_val 						= $param1;
			if (
			$this->base_model->check_duplicate($table_name, $cond, $cond_val) && 
			is_numeric($param1)
			) {
				$status 					= "cancelled";
				$data 						= array('is_conformed' => $status);
				if ($this->db->update(
						$table_name, $data, 
						array('id' => $param1)
						)) {
					$this->prepare_flashmessage($this->lang->line('status_canceled') , 0);
					redirect('users/myBookings', 'refresh');
				}
				else {
					$this->prepare_flashmessage($this->lang->line('unable_to_cancel_status') , 1);
					redirect('users/myBookings');
				}
			}
			else {
				$this->prepare_flashmessage($this->lang->line('invalid') . 
				" " . $this->lang->line('operation') , 1);
				redirect('users/myBookings', 'refresh');
			}
		}

		$this->data['booking_history'] 		= $this->db->get_where(
												'vbs_bookings', 
												array('user_id' => $this->ion_auth->get_user_id())
												)->result();
		$this->data['css_type'] 			= array('datatable');
		$this->data['title'] 				= 'Booking History';
		$this->data['content'] 				= "users/booking_history";
		$this->_render_page('templates/site_template', $this->data);
	}

	function profile()
	{
		if (!$this->ion_auth->logged_in() && !$this->ion_auth->is_member()) 
			redirect('auth', 'refresh');
		$this->data['message'] 				= "";
		if ($this->input->post('submit') == "Update") {
			// FORM VALIDATIONS
			$this->form_validation->set_rules('user_name', 'User Name', 'xss_clean|required');
			$this->form_validation->set_rules('email', 'Email', 'valid_email|xss_clean|required');
			$this->form_validation->set_rules('first_name', 'First Name', 'xss_clean|required');
			$this->form_validation->set_rules('last_name', 'Last Name', 'xss_clean|required');
			$this->form_validation->set_rules('phone', 'Phone', 'xss_clean|required');
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			if ($this->form_validation->run() == TRUE) {
				$inputdata['username'] 		= $this->input->post('user_name');
				$inputdata['email'] 		= $this->input->post('email');
				$inputdata['first_name'] 	= $this->input->post('first_name');
				$inputdata['last_name'] 	= $this->input->post('last_name');
				$inputdata['phone'] 		= $this->input->post('phone');
				$table_name 				= "users";
				$where['id'] 				= $this->ion_auth->get_user_id();
				if ($this->base_model->update_operation($inputdata, $table_name, $where)) {
					$this->prepare_flashmessage($this->lang->line('update_success') , 0);
					redirect('users/profile', 'refresh');
				}
				else {
					$this->prepare_flashmessage($this->lang->line('unable_to_update') , 1);
					redirect('users/profile');
				}
			}
		}

		$this->data['profile_info'] 	= $this->db->get_where(
											'vbs_users', 
											array('id' => $this->ion_auth->get_user_id())
											)->result() [0];
		$this->data['css_type'] 		= array('form');
		$this->data['title'] 			= $this->lang->line('profile');
		$this->data['content'] 			= "users/profile";
		$this->_render_page('templates/site_template', $this->data);
	}

	function changePassword()
	{
		if (!$this->ion_auth->logged_in() && !$this->ion_auth->is_member()) {
			redirect('auth', 'refresh');
		}
		$this->form_validation->set_rules('old', $this->lang->line('change_password_validation_old_password_label') , 'required');
		$this->form_validation->set_rules(
										'new_password', 
										$this->lang->line('change_password_validation_new_password_label') , 'required|min_length[' . $this->config->item('min_password_length', 'ion_auth') . 
										']|max_length[' . 
										$this->config->item('max_password_length', 'ion_auth') . ']|matches[new_confirm]'
										);
		$this->form_validation->set_rules('new_confirm', $this->lang->line('change_password_validation_new_password_confirm_label') , 'required');
		$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
		$user = $this->ion_auth->user()->row();
		if ($this->form_validation->run() == false) {

			// display the form
			// set the flash data error message if there is one
			$this->data['min_password_length'] = $this->config->item(
												'min_password_length', 
												'ion_auth'
												);
			$this->data['old_password'] = array(
												'name' => 'old',
												'id' => 'old',
												'type' => 'password',
												'placeholder' => $this->lang->line('old_password') ,
												);
			$this->data['new_password'] = array(
													'name' => 'new_password',
													'id' => 'new',
													'type' => 'password',
													'pattern' => '^.{' . $this->data['min_password_length'] . '}.*$',
													'placeholder' => $this->lang->line('new_password') ,
												);
			$this->data['new_password_confirm'] = array(
														'name' => 'new_confirm',
														'id' => 'new_confirm',
														'type' => 'password',
														'pattern' => '^.{' . $this->data['min_password_length'] . '}.*$',
														'placeholder' => $this->lang->line('confirm_password') ,
													);
			$this->data['user_id'] 				= array(
														'name' => 'user_id',
														'id' => 'user_id',
														'type' => 'hidden',
														'value' => $user->id,
													);
			$this->data['css_type'] 			= array('form');
			$this->data['title'] 				= 'Change Password';
			$this->data['content'] 				= "users/change_password";
			$this->_render_page('templates/site_template', $this->data);
		}
		else {
			$identity 							= $this->session->userdata('identity');
			$change 							= $this->ion_auth->change_password(
													$identity, 
													$this->input->post('old'), 
													$this->input->post('new_password')
													);
			if ($change) {

			// if the password was successfully changed
				$this->prepare_flashmessage($this->lang->line('password_changed_success') , 0);
				redirect('users/changePassword', 'refresh');
			}
			else {
				$this->prepare_flashmessage($this->ion_auth->errors() , 1);
				redirect('users/changePassword', 'refresh');
			}
		}
	}
}
/* End of file users.php */
/* Location: ./application/controllers/users.php */
?>