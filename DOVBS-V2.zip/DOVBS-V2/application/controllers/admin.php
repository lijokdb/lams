<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Admin extends MY_Controller

{	
	/*
	| -----------------------------------------------------
	| PRODUCT NAME: 	DIGI VEHICLE BOOKING SYSTEM (DVBS)
	| -----------------------------------------------------
	| AUTHOR:			DIGITAL VIDHYA TEAM
	| -----------------------------------------------------
	| EMAIL:			digitalvidhya4u@gmail.com
	| -----------------------------------------------------
	| COPYRIGHTS:		RESERVED BY DIGITAL VIDHYA
	| -----------------------------------------------------
	| WEBSITE:			http://digitalvidhya.com
	|                   http://codecanyon.net/user/digitalvidhya
	| -----------------------------------------------------
	|
	| MODULE: 			Admin
	| -----------------------------------------------------
	| This is Admin module controller file.
	| -----------------------------------------------------
	*/
	
	function __construct()
	{
		parent::__construct();
		$this->load->library('ion_auth');
		$this->load->library('form_validation');
		$this->load->helper('url');

		// Load MongoDB library instead of native db driver if required

		$this->config->item('use_mongodb', 'ion_auth') ? $this->load->library('mongo_db') : $this->load->database();
		$this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth') , $this->config->item('error_end_delimiter', 'ion_auth'));
		$this->lang->load('auth');
		$this->load->helper('language');
		
		if(!$this->ion_auth->logged_in() || $this->ion_auth->is_member())
		   redirect('auth');
	}

	public function index()
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin())
				redirect('auth', 'refresh');
				
				
		$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');
		$today = date("Y-m-d");
		$todaybookings = $this->base_model->run_query("SELECT b.*,v.name FROM vbs_bookings AS b , vbs_vehicle AS v WHERE b.vehicle_selected = v.id AND  b.bookdate = '" . $today . "' AND b.is_conformed = 'pending' ORDER BY b.pick_date ASC LIMIT 10");
		if (count($todaybookings) > 0) $this->data['todaybookings'] = $todaybookings;
		else $this->data['todaybookings'] = array();
		/****** Recent Bookings Chart Data ******/
		$records = $this->base_model->run_query('SELECT bookdate, count(IF(is_conformed="confirm",1,NULL)) AS confirmed_bookings,
						count(IF(is_conformed="cancelled",1,NULL)) AS cancelled_bookings, 
						count(IF(is_conformed="pending",1,NULL)) AS pending_bookings, 
						count(*) AS total_bookings 
						FROM ' . $this->db->dbprefix("bookings") . ' GROUP BY bookdate
						ORDER BY id DESC LIMIT 4');
		
		if (count($records) > 0) {
			$result 						= array();
			$temp 							= array();
			array_push($temp, $this->lang->line('date') , $this->lang->line('total_bookings') , $this->lang->line('cancelled_bookings') , $this->lang->line('pending_bookings') , $this->lang->line('confirmed_bookings'));
			array_push($result, $temp);
			foreach($records as $d) {
				$temp 						= array();
				array_push($temp, date('M d', strtotime($d->bookdate)) , $d->total_bookings, $d->cancelled_bookings, $d->pending_bookings, $d->confirmed_bookings);
				array_push($result, $temp);
			}

			$str = "";
			$cnt = 0;
			foreach($result as $r) {
				if ($cnt++ == 0) {
					$str = $str . "['" . $r[0] . "','" . $r[1] . "','" . $r[2] . "','" . $r[3] . "','" . $r[4] . "'],";
				}
				else {
					$str = $str . "['" . $r[0] . "'," . $r[1] . "," . $r[2] . "," . $r[3] . "," . $r[4] . "],";
				}
			}

			$this->data['result'] = $str;
		}

		$customers = $this->db->query("select u.* from vbs_users u, vbs_users_groups g where u.id=g.user_id and g.group_id='2' GROUP BY u.id ORDER BY u.date_of_registration DESC LIMIT 10")->result();
		$members = $this->db->query("select u.* from vbs_users u, vbs_users_groups g where u.id=g.user_id and u.active='1' and g.group_id='2'")->result();
		$n = count($members);
		$inactiveMembers = $this->db->query("select u.* from vbs_users u, vbs_users_groups g where u.id=g.user_id and u.active='0' and g.group_id='2'")->result();
		$im = count($inactiveMembers);
		$executives = $this->db->query("select u.* from vbs_users u, vbs_users_groups g where u.id=g.user_id  and u.active='1' and g.group_id='3'")->result();
		$e = count($executives);
		$inactiveExecutives = $this->db->query("select u.* from vbs_users u, vbs_users_groups g where u.id=g.user_id  and u.active='0' and g.group_id='3'")->result();
		$ie = count($inactiveExecutives);
		$vehicles = $this->db->query("select * from vbs_vehicle where status='active'")->result();

		$v = count($vehicles);
		$airports = $this->db->query("select * from vbs_airports where status='active'")->result();
		$a = count($airports);
		$package = $this->db->query("select p.* from vbs_package_settings p where p.status='Active' AND EXISTS (select v.id from vbs_vehicle v where v.id=p.vehicle_id AND v.status='Active')")->result();
		$p = count($package);
		$bookings = $this->db->query("select * from vbs_bookings")->result();
		$b = count($bookings);


		$this->data['n'] 			= $n;
		$this->data['im'] 			= $im;
		$this->data['e'] 			= $e;
		$this->data['ie'] 			= $ie;
		$this->data['v'] 			= $v;
		$this->data['a'] 			= $a;
		$this->data['p'] 			= $p;
		$this->data['b'] 			= $b;
		$this->data['customers'] 	= $customers;
		$this->data['css_type'] 	= array("form","datatable");
		$this->data['gmaps'] 		= "false";
		$this->data['active_class'] = "dashboard";
		$this->data['title'] 		= 'Welcome to DVBS';
		$this->data['content'] 		= 'admin/dashboard';
		$this->_render_page('templates/admin_template', $this->data);
	}

	public function form_view()
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) redirect('auth', 'refresh');
		$this->data['css_type'] 			= array("form","datatable");
		$this->data['title'] 				= 'Add Vechicle';
		$this->data['content'] 				= 'admin/settings/vechicle_add';
		$this->_render_page('templates/admin_template', $this->data);
	}

	/******	CRUD OPERATIONS FOR ADD EXECUTIVES - START	******/
	public function executives()
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) redirect('auth', 'refresh');

		// $executives = $this->db->get_where($this->db->dbprefix('users'),array('active'=>'1'))->result();

		$executives = $this->db->query("select u.* from vbs_users u,vbs_users_groups g where  u.id=g.user_id and g.group_id='3' GROUP BY u.id")->result();
		$this->data['gmaps'] 		= "false";
		$this->data['executives'] 	= $executives;
		$this->data['css_type'] 	= array("form","datatable");
		$this->data['title'] 		= $this->lang->line('executives');
		$this->data['active_class'] = "users";
		$this->data['content'] 		= 'admin/executives/executives';
		$this->_render_page('templates/admin_template', $this->data);
	}

	public function addExecutives($param = NULL, $param2 = NULL)
	{
		$this->data['message'] = "";
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth');
		}

		$this->data['user'] 				= array();
		$this->data['operation'] 			= "Add";
		if ($this->input->post('submit') == $this->lang->line('add')) {
			$tables = $this->config->item('tables', 'ion_auth');

			// validate form input

			$this->form_validation->set_rules(
												'first_name', 
												$this->lang->line('create_user_validation_fname_label') ,'required|xss_clean'
											  );
			$this->form_validation->set_rules(
												'last_name', 
												$this->lang->line('create_user_validation_lname_label') ,'xss_clean'
											);
			$this->form_validation->set_rules('email', 
										$this->lang->line('create_user_validation_email_label') , 'required|valid_email|is_unique[' . $tables['users'] . '.email]'
											 );
			$this->form_validation->set_rules(
												'phone',
												$this->lang->line('create_user_validation_phone_label') ,'required|xss_clean|integer'
											 );
			$this->form_validation->set_rules('password', $this->lang->line('create_user_validation_password_label') , 'required|min_length[' . $this->config->item('min_password_length', 'ion_auth') . ']|max_length[' . $this->config->item('max_password_length', 'ion_auth') . ']|matches[confirm_password]');
			$this->form_validation->set_rules('confirm_password', $this->lang->line('create_user_validation_password_confirm_label') , 'required');
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			if ($this->form_validation->run() == true) {
				$username = $this->input->post('first_name') . ' ' . $this->input->post('last_name');
				$email = strtolower($this->input->post('email'));
				$password = $this->input->post('password');
				$additional_data = array(
					'first_name' => $this->input->post('first_name') ,
					'last_name' => $this->input->post('last_name') ,
					'phone' => $this->input->post('phone') ,
					'active' => $this->input->post('status') ,
					'date_of_registration' => date('Y-m-d')
				);
				$group = array(
					'group_id' => '3'
				);
			}
			
			if ($this->form_validation->run() == true && $this->ion_auth->register($username, $password, $email, $additional_data, $group)) {

				// check to see if we are creating the user
				// redirect them back to the admin page

				$this->prepare_flashmessage($this->ion_auth->messages() , 0);
				redirect("admin/executives", 'refresh');
			}
		}

		$this->data['gmaps'] 		= "false";
		$this->data['css_type'] 	= array("form","datatable");
		$this->data['title'] 		= $this->lang->line('add_executive');
		$this->data['active_class'] = "users";
		$this->data['content'] 		= 'admin/executives/addExecutives';
		$this->_render_page('templates/admin_template', $this->data);
	}

	public function editExecutive($param = '', $param1 = '')
	{
		$this->data['message'] = "";
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) redirect('auth', 'refresh');
		$table_name = "users";
		if ($this->input->post('submit') == $this->lang->line('update')) {

			// FORM VALIDATIONS

			$this->form_validation->set_rules('first_name', 'First Name', 'xss_clean|trim|required');
			$this->form_validation->set_rules('last_name', 'Last Name', 'xss_clean');
			$this->form_validation->set_rules('email', 'Email', 'xss_clean|trim|required');
			$this->form_validation->set_rules('phone', 'Phone', 'xss_clean|trim|required');
			$this->form_validation->set_rules('status', 'Status', 'xss_clean');
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			$param1 = $this->input->post('update_rec_id');
			if ($this->form_validation->run() == TRUE) {
				
				$inputdata['first_name'] 	= $this->input->post('first_name');
				$inputdata['last_name'] 	= $this->input->post('last_name');
				$inputdata['email'] 		= $this->input->post('email');
				$inputdata['phone'] 		= $this->input->post('phone');
				$inputdata['active'] 		= $this->input->post('status');
				$where['id'] 				= $this->input->post('update_rec_id');
				if ($this->base_model->update_operation($inputdata, $table_name, $where)) {
					$this->prepare_flashmessage($this->lang->line('user') . " " . $this->lang->line('update_success') , 0);
					redirect('admin/executives', 'refresh');
				}
				else {
					$this->prepare_flashmessage($this->lang->line('unable_to_update') . " " . $this->lang->line('user') , 1);
					redirect('admin/executives');
				}
			}
		}

		$user = $this->db->query("select u.* from vbs_users u,vbs_users_groups g where  u.id=g.user_id and g.group_id='3' and u.id= " . $param1 . " GROUP BY u.id")->result();
		$this->data['user'] 				= $user[0];
		$this->data['css_type'] 			= array('form');
		$this->data['title'] 				= $this->lang->line('edit_executive');
		$this->data['operation'] 			= "Edit";
		$this->data['active_class'] 		= "users";
		$this->data['content'] 				= "admin/executives/edit_executives";
		$this->_render_page('templates/admin_template', $this->data);
	}

	public function deleteExecutive($param = '', $param1 = '')
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) redirect('auth', 'refresh');
		$table_name 						= "users";
		$where['id'] 						= $param1;
		$cond 								= "id";
		$cond_val 							= $param1;
		if ($this->base_model->check_duplicate($table_name, $cond, $cond_val) && is_numeric($param1)) {
			
			if ($this->base_model->delete_record($table_name, $where)) {
				$this->prepare_flashmessage($this->lang->line('user') . " " . $this->lang->line('delete_success') , 0);
				redirect('admin/executives', 'refresh');
			}
			else {
				$this->prepare_flashmessage($this->lang->line('unable_to_delete') . " " . $this->lang->line('user') , 1);
				redirect('admin/executives');
			}
		}
		else {
			$this->prepare_flashmessage($this->lang->line('invalid') . " " . $this->lang->line('operation') , 1);
			redirect('admin/executives', 'refresh');
		}
	}

	function create_user()
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) redirect('auth', 'refresh');
		$this->data['title'] = "Create User";
		$this->config->load('ion_auth', TRUE);
		$tables = $this->config->item('tables', 'ion_auth');
		if ($this->input->post('submit') != '') {

			// validate form input

			$this->form_validation->set_rules('first_name', $this->lang->line('create_user_validation_fname_label') , 'required|xss_clean');
			$this->form_validation->set_rules('last_name', $this->lang->line('create_user_validation_lname_label') , 'required|xss_clean');
			$this->form_validation->set_rules('email', $this->lang->line('create_user_validation_email_label') , 'required|valid_email|is_unique[' . $tables['users'] . '.email]');
			$this->form_validation->set_rules('phone', $this->lang->line('create_user_validation_phone_label') , 'required|xss_clean|integer');
			$this->form_validation->set_rules('password', $this->lang->line('create_user_validation_password_label') , 'required|min_length[' . $this->config->item('min_password_length', 'ion_auth') . ']|max_length[' . $this->config->item('max_password_length', 'ion_auth') . ']|matches[password_confirm]');
			$this->form_validation->set_rules('password_confirm', $this->lang->line('create_user_validation_password_confirm_label') , 'required');
			if ($this->form_validation->run() == true) {
				$username = $this->input->post('first_name') . ' ' . $this->input->post('last_name');
				$email 						= strtolower($this->input->post('email'));
				$password 					= $this->input->post('password');
				$additional_data 			= array('first_name' => $this->input->post('first_name') ,
												'last_name' => $this->input->post('last_name') ,
												'phone' => $this->input->post('phone') ,
												'date_of_registration' => date('Y-m-d')
												);
			}
			
			if ($this->form_validation->run() == true && $this->ion_auth->register($username, $password, $email, $additional_data)) {

				// check to see if we are creating the user
				// redirect them back to the admin page

				$this->prepare_flashmessage($this->ion_auth->messages() , 0);
				redirect("admin/executives", 'refresh');
			}
			else {

				// display the create user form
				// set the flash data error message if there is one

				$this->prepare_flashmessage((validation_errors() ? validation_errors() : ($this->ion_auth->errors() ? $this->ion_auth->errors() : $this->session->flashdata('message'))) , 1);
				redirect("admin/addExecutives", 'refresh');
			}
		}

		$this->data['css'] 					= array('form');
		$this->data['title'] 				= 'Business User Sign Up';
		$this->data['content'] 				= 'site/register';
		$this->_render_page('templates/site_template', $this->data);
	}

	public function profile()
	{
		$this->data['message'] = "";
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) redirect('auth', 'refresh');
		if ($this->input->post('submit') == "Update") {

			// FORM VALIDATIONS

			$this->form_validation->set_rules('user_name', 'User Name', 'xss_clean|required');
			$this->form_validation->set_rules('email', 'Email', 'valid_email|xss_clean|required');
			$this->form_validation->set_rules('first_name', 'First Name', 'xss_clean|required');
			$this->form_validation->set_rules('last_name', 'Last Name', 'xss_clean|required');
			$this->form_validation->set_rules('phone', 'Phone', 'xss_clean|required');
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			if ($this->form_validation->run() == TRUE) {
				$inputdata['username'] 		= $this->input->post('user_name');
				$inputdata['email'] 		= $this->input->post('email');
				$inputdata['first_name'] 	= $this->input->post('first_name');
				$inputdata['last_name'] 	= $this->input->post('last_name');
				$inputdata['phone'] 		= $this->input->post('phone');
				$table_name 				= "users";
				$where['id'] 				= $this->input->post('update_rec_id');
				
				
				
				if ($this->base_model->update_operation($inputdata, $table_name, $where)) {
					$this->prepare_flashmessage("Updated Successfully", 0);
					redirect('admin/profile', 'refresh');
				}
				else {
					$this->prepare_flashmessage("Unable to update", 1);
					redirect('admin/profile');
				}
			}
		}

		$admin_details = $this->db->get_where('users', array(
			'id' => $this->ion_auth->get_user_id()
		))->row();

		// echo "<pre>"; print_r($admin_details); die();

		$this->data['admin_details'] 		= $admin_details;
		$this->data['css_type'] 			= array('form');
		$this->data['gmaps'] 				= "false";
		$this->data['title'] 				= 'Profile';
		$this->data['content'] 				= 'admin/admin_profile';
		$this->_render_page('templates/admin_template', $this->data);
	}

	public function customers()
	{
		if (!$this->ion_auth->logged_in() || !($this->ion_auth->is_admin() || $this->ion_auth->is_executive())) redirect('auth', 'refresh');
		$customers = $this->db->query("select u.* from vbs_users u, vbs_users_groups g where u.id=g.user_id and g.group_id='2' GROUP BY u.id")->result();
		$this->data['gmaps'] 				= "false";
		$this->data['customers'] 			= $customers;
		$this->data['css_type'] 			= array("form","datatable");
		$this->data['title'] 				= $this->lang->line('customers');
		$this->data['active_class'] 		= "users";
		$this->data['content'] 				= 'admin/customers/customers';
		$template 							= "admin_template";
		if ($this->ion_auth->is_executive()) $template = "executive_template";
		$this->_render_page('templates/' . $template, $this->data);
	}

	public function addCustomers($param = NULL, $param2 = NULL)
	{
		$this->data['message'] = "";
		
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) {
			redirect('auth');
		}

		$this->data['user'] 			= array();
		$this->data['operation'] 		= "Add";
		if ($this->input->post('submit') == $this->lang->line('add')) {
			$tables = $this->config->item('tables', 'ion_auth');

			// validate form input

			$this->form_validation->set_rules('first_name', $this->lang->line('create_user_validation_fname_label') , 'required|xss_clean');
			$this->form_validation->set_rules('last_name', $this->lang->line('create_user_validation_lname_label') , 'required|xss_clean');
			$this->form_validation->set_rules('email', $this->lang->line('create_user_validation_email_label') , 'required|valid_email|is_unique[' . $tables['users'] . '.email]');
			$this->form_validation->set_rules('phone', $this->lang->line('create_user_validation_phone_label') , 'required|xss_clean|integer');
			$this->form_validation->set_rules('password', $this->lang->line('create_user_validation_password_label') , 'required|min_length[' . $this->config->item('min_password_length', 'ion_auth') . ']|max_length[' . $this->config->item('max_password_length', 'ion_auth') . ']|matches[confirm_password]');
			$this->form_validation->set_rules('confirm_password', $this->lang->line('create_user_validation_password_confirm_label') , 'required');
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			if ($this->form_validation->run() == true) {
				$username = $this->input->post('first_name') . ' ' . $this->input->post('last_name');
				$email 						= strtolower($this->input->post('email'));
				$password 					= $this->input->post('password');
				$additional_data 			= array(
												'first_name' => $this->input->post('first_name') ,
												'last_name' => $this->input->post('last_name') ,
												'phone' => $this->input->post('phone') ,
												'active' => $this->input->post('status') ,
												'date_of_registration' => date('Y-m-d')
												);
				$group 						= array('group_id' => '2');
			}
				
			if ($this->form_validation->run() == true && $this->ion_auth->register($username, $password, $email, $additional_data, $group)) {

				// check to see if we are creating the user
				// redirect them back to the admin page

				$this->prepare_flashmessage($this->ion_auth->messages() , 0);
				redirect("admin/customers", 'refresh');
			}
		}

		$this->data['gmaps'] 				= "false";
		$this->data['css_type'] 			= array("form","datatable");
		$this->data['title'] 				= $this->lang->line('add_customer');
		$this->data['active_class'] 		= "users";
		$this->data['content'] 				= 'admin/customers/addCustomers';
		$this->_render_page('templates/admin_template', $this->data);
	}

	public function deleteCustomer($param = '', $param1 = '')
	{
		if (!$this->ion_auth->logged_in() || !$this->ion_auth->is_admin()) redirect('auth', 'refresh');
		$table_name 						= "users";
		$where['id'] 						= $param1;
		$cond 								= "id";
		$cond_val 							= $param1;
		if ($this->base_model->check_duplicate($table_name, $cond, $cond_val) && is_numeric($param1)) {
			
			if ($this->base_model->delete_record($table_name, $where)) {
				$this->prepare_flashmessage($this->lang->line('user') . " " . $this->lang->line('delete_success') , 0);
				redirect('admin/customers', 'refresh');
			}
			else {
				$this->prepare_flashmessage($this->lang->line('unable_to_delete') . " " . $this->lang->line('user') , 1);
				redirect('admin/customers');
			}
		}
		else {
			$this->prepare_flashmessage($this->lang->line('invalid') . " " . $this->lang->line('operation') , 1);
			redirect('admin/customers', 'refresh');
		}
	}

	public function bookingDetails($param = '')
	{
		if (!$this->ion_auth->logged_in() || !($this->ion_auth->is_admin() || $this->ion_auth->is_executive())) redirect('auth', 'refresh');
		$table_name 						= "bookings";
		$where['id'] 						= $param;
		$bookings = $this->base_model->run_query("SELECT b.*,v.name FROM vbs_bookings AS b , vbs_vehicle AS v WHERE b.vehicle_selected = v.id AND b.id='" . $where['id'] . "'");
		if (is_numeric($param)) {
			$inputdata['is_new'] 			= 1;
			$table 							= "bookings";
			$where['id'] 					= $param;
			
			$this->base_model->update_operation($inputdata, $table, $where);
		}
		
		
		$this->data['gmaps'] 				= "false";
		$this->data['css_type'] 			= array();
		$this->data['bookings'] 			= $bookings;
		$this->data['active_class'] 		= "bookings";
		$this->data['title'] 				= $this->lang->line('booking_details');
		$this->data['content'] 				= 'admin/booking_details';
		$template 							= "admin_template";
		if ($this->ion_auth->is_executive()) $template = "executive_template";
		$this->_render_page('templates/' . $template, $this->data);
	}

	public function userDetails($param = '')
	{
		if (!$this->ion_auth->logged_in() || !($this->ion_auth->is_admin() || $this->ion_auth->is_executive())) redirect('auth', 'refresh');
		$table_name 						= "users";
		$where['id'] 						= $param;
		$users = $this->base_model->run_query("SELECT * FROM vbs_users WHERE id='" . $where['id'] . "'");
		$this->data['gmaps'] 				= "false";
		$this->data['css_type'] 			= array();
		$this->data['users'] 				= $users;
		$this->data['title'] 				= $this->lang->line('user') .
												" " . $this->lang->line('details');
		$this->data['content'] 				= 'admin/user_details';
		$template 							= "admin_template";
		if ($this->ion_auth->is_executive()) $template = "executive_template";
		$this->_render_page('templates/' . $template, $this->data);
	}

	function deactivate($id, $param = '', $code = false)
	{
		
		if ($code !== false) {
			$deactivation = $this->ion_auth->deactivate($id, $code);
		}
		else
		if ($this->ion_auth->is_admin()) {
			$deactivation = $this->ion_auth->deactivate($id);
		}

		if ($param == "users") {
			$this->prepare_flashmessage($this->ion_auth->messages() , 0);
			redirect("admin/userDetails/" . $id, 'refresh');
		}

		if ($param == "exe") {
			$this->prepare_flashmessage($this->ion_auth->messages() , 0);
			redirect("admin/executives", 'refresh');
		}

		if ($deactivation) {

			// redirect them to the auth page

			$this->prepare_flashmessage($this->ion_auth->messages() , 0);

			// $this->session->set_flashdata('message', $this->ion_auth->messages());

			redirect("admin/customers", 'refresh');
		}
	}

	// activate the user

	function activate($id, $param = '', $code = false)
	{
		
		if ($code !== false) {
			$activation = $this->ion_auth->activate($id, $code);
		}
		else
		if ($this->ion_auth->is_admin()) {
			$activation = $this->ion_auth->activate($id);
		}

		if ($param == "users") {
			$this->prepare_flashmessage($this->ion_auth->messages() , 0);
			redirect("admin/userDetails/" . $id, 'refresh');
		}

		if ($param == "exe") {
			$this->prepare_flashmessage($this->ion_auth->messages() , 0);
			redirect("admin/executives", 'refresh');
		}

		if ($activation) {

			// redirect them to the auth page

			$this->prepare_flashmessage($this->ion_auth->messages() , 0);

			// $this->session->set_flashdata('message', $this->ion_auth->messages());

			redirect("admin/customers", 'refresh');
		}
	}
	
	
	
}