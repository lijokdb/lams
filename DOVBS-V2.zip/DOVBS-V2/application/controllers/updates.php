<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');



class Updates extends MY_Controller {



/*

| -----------------------------------------------------

| PRODUCT NAME: 	DIGI ONLINE VEHICLE BOOKING SYSTEM (DOVBS)

| -----------------------------------------------------

| AUTHER:			DIGITAL VIDHYA TEAM

| -----------------------------------------------------

| EMAIL:			digitalvidhya4u@gmail.com

| -----------------------------------------------------

| COPYRIGHTS:		RESERVED BY DIGITAL VIDHYA

| -----------------------------------------------------

| WEBSITE:			http://digitalvidhya.com

|                   http://codecanyon.net/user/digitalvidhya      

| -----------------------------------------------------

|

| MODULE: 			General

| -----------------------------------------------------

| This is general module controller file.

| -----------------------------------------------------

*/



	

	function __construct()

    {

        parent::__construct();
		
		

		$this->load->library('form_validation');

		$this->load->helper('url');
		

    } 

	

	//Home Page (Default Function. If no function is called, this function will be called).	
	public function index()

	{
		$this->load->dbforge();
		
		//Alter site_settings table

	if (!$this->db->field_exists('currency_symbol', 

		$this->db->dbprefix('site_settings'))) {

	   		

		$fields = array(

	    'currency_symbol' => array(

								'type' => 'varchar',

								'constraint' => '512',

								'Default' => ''

							)

							);

		$this->dbforge->add_column('site_settings', $fields);

		 

		 }
	if (!$this->db->field_exists('site_title', 

		$this->db->dbprefix('site_settings'))) {

	   		

		$fields = array(

	    'site_title' => array(

								'type' => 'varchar',

								'constraint' => '512',

								'Default' => ''

							)

							);

		$this->dbforge->add_column('site_settings', $fields);

		 

		 }

		//Alter site_settings table

	if (!$this->db->field_exists('driver_charge_night', 

		$this->db->dbprefix('site_settings'))) {

	   		

		$fields = array(

	    'driver_charge_night' => array(

								'type' => 'int',

								'constraint' => '11',

								'Default' => '0'

							)

							);

		$this->dbforge->add_column('site_settings', $fields);

		 

		 }

		
		//SCRIPT FOR UNICODE SUPPORT START
		$results = $this->base_model->run_query('SHOW TABLES');

		$char_set = 'utf8'; 

		

		$table_name="vbs_airports";

				$query = "ALTER TABLE $table_name CONVERT TO CHARACTER SET $char_set COLLATE utf8_general_ci";

				$this->db->query($query);

				
			redirect('auth');

	}

	function convert()
	{
		//SCRIPT FOR UNICODE SUPPORT START
$results = $this->base_model->run_query('SHOW TABLES');

$char_set = 'utf8'; 

foreach($results as $tables) {

foreach($tables as $table_name) {
if($table_name!='vbs_calendar|timezones')
$query = "ALTER TABLE $table_name CONVERT TO CHARACTER SET $char_set COLLATE utf8_general_ci";

if($this->db->query($query))

echo "$table_name table converted sucessfully.. <br>";

}

}


$query = "ALTER DATABASE CHARACTER SET $char_set;";  

if($this->db->query($query))

print "\nDatabase collation has been updated successfully.\n"; 
	}

	

 }



/* End of file updates.php */

/* Location: ./application/controllers/updates.php */